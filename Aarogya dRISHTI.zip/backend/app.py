﻿"""Flask application for the AarogyaDrishti research workflow.

The web layer deliberately keeps authentication, study handling, and
research-only inference in one place so the safety boundaries are easy to
review. It is not a clinical diagnostic service.
"""

import hmac
import json
from io import BytesIO
import logging
import os
import re
import secrets
import sqlite3
import subprocess
import sys
import threading
from functools import lru_cache
from pathlib import Path

from flask import (
    Flask,
    abort,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from PIL import Image, UnidentifiedImageError
from werkzeug.security import check_password_hash, generate_password_hash
from torchvision import transforms

from .core import SUPPORTED_ARCHITECTURES, load_run, read_manifest
from .predict import predict_tensor
from .selective import load_calibration
from .safety import aggregate_patient_predictions, append_audit_event, image_digest
from .medical_formats import validate_medical_file
from .explainability import saliency_map

PROJECT_DIR = Path(__file__).resolve().parent.parent
MAX_UPLOAD_BYTES = 10 * 1024 * 1024
MAX_REQUEST_BYTES = MAX_UPLOAD_BYTES + 64 * 1024
MAX_IMAGE_PIXELS = 16_000_000
ALLOWED_EXTENSIONS = {".png", ".jpg", ".jpeg"}
RUN_NAME_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,39}$")
MAX_LOG_LINES = 80

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
_job_lock = threading.Lock()
_job_state_lock = threading.Lock()
_job_state = {"running": False, "stage": "idle", "message": "", "log": [], "error": None}


@lru_cache(maxsize=4)
def _load_predictor(run_directory):
    calibration = load_calibration(run_directory)
    model, checkpoint = load_run(run_directory)
    return model, checkpoint, calibration


def _model_directory(runs_directory, run_name):
    candidate = (Path(runs_directory).resolve() / run_name).resolve()
    root = Path(runs_directory).resolve()
    if candidate.parent != root:
        raise ValueError("Invalid model selection.")
    model_directory = candidate / "model" if (candidate / "model").is_dir() else candidate
    return model_directory


def _db_connect(database_path):
    connection = sqlite3.connect(database_path, timeout=10)
    connection.row_factory = sqlite3.Row
    return connection


def _ensure_secret_key(instance_path):
    configured_key = os.environ.get("AAROGYADRISHTI_SECRET_KEY")
    if configured_key:
        return configured_key
    key_path = Path(instance_path) / "secret_key"
    if key_path.exists():
        return key_path.read_text(encoding="utf-8").strip()
    key = secrets.token_urlsafe(48)
    key_path.write_text(key, encoding="utf-8")
    try:
        key_path.chmod(0o600)
    except OSError:
        logger.warning("Could not restrict permissions on the local Flask secret key.")
    return key


def _initialize_auth(database_path):
    with _db_connect(database_path) as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        user_columns = {
            row["name"]
            for row in connection.execute("PRAGMA table_info(users)").fetchall()
        }
        if "role" not in user_columns:
            connection.execute(
                "ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'"
            )
            connection.execute(
                "UPDATE users SET role = 'admin' WHERE id = "
                "(SELECT id FROM users ORDER BY id LIMIT 1)"
            )
        admin_count = connection.execute(
            "SELECT COUNT(*) AS count FROM users WHERE role = 'admin'"
        ).fetchone()["count"]
        if admin_count == 0:
            connection.execute(
                "UPDATE users SET role = 'admin' WHERE id = "
                "(SELECT id FROM users ORDER BY id LIMIT 1)"
            )
        elif admin_count > 1:
            connection.execute(
                "UPDATE users SET role = 'user' WHERE role = 'admin' "
                "AND id != (SELECT id FROM users WHERE role = 'admin' ORDER BY id LIMIT 1)"
            )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS studies (
                study_id TEXT PRIMARY KEY,
                user TEXT NOT NULL,
                model TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                image_count INTEGER NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS review_queue (
                review_id TEXT PRIMARY KEY,
                study_id TEXT NOT NULL,
                inference_id TEXT NOT NULL,
                model TEXT,
                status TEXT NOT NULL DEFAULT 'pending',
                decision TEXT,
                reason TEXT,
                reviewed_by TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                reviewed_at TEXT
            )
            """
        )
        review_columns = {
            row["name"]
            for row in connection.execute("PRAGMA table_info(review_queue)").fetchall()
        }
        for column, definition in (
            ("model", "TEXT"),
            ("reviewed_by", "TEXT"),
            ("owner", "TEXT"),
        ):
            if column not in review_columns:
                connection.execute(
                    f"ALTER TABLE review_queue ADD COLUMN {column} {definition}"
                )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS model_registry (
                model TEXT PRIMARY KEY,
                checkpoint_sha256 TEXT NOT NULL,
                metadata_json TEXT NOT NULL,
                active INTEGER NOT NULL DEFAULT 1,
                registered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS monitoring_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event TEXT NOT NULL,
                model TEXT,
                status TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )


def _user_exists(database_path):
    with _db_connect(database_path) as connection:
        return connection.execute("SELECT 1 FROM users LIMIT 1").fetchone() is not None


def _current_user(database_path):
    username = session.get("user_id")
    if not username:
        return None
    with _db_connect(database_path) as connection:
        return connection.execute(
            "SELECT username, role FROM users WHERE username = ?", (username,)
        ).fetchone()


def _request_is_local():
    return request.remote_addr in {"127.0.0.1", "::1", "localhost"}


def _csrf_valid():
    supplied = request.headers.get("X-CSRFToken") or request.form.get("csrf_token", "")
    expected = session.get("csrf_token", "")
    return bool(supplied and expected and hmac.compare_digest(supplied, expected))


def _password_policy(password, username):
    if len(password) < 12:
        return "Use a password with at least 12 characters."
    if password.casefold() == username.casefold():
        return "Password must not match the username."
    character_classes = sum(
        (
            any(character.islower() for character in password),
            any(character.isupper() for character in password),
            any(character.isdigit() for character in password),
            any(not character.isalnum() for character in password),
        )
    )
    if character_classes < 3:
        return "Use at least 3 of lowercase, uppercase, number, and symbol."
    return None


def _append_job_log(line):
    with _job_state_lock:
        _job_state["log"].append(line.rstrip())
        _job_state["log"] = _job_state["log"][-MAX_LOG_LINES:]


def _set_job_state(**updates):
    with _job_state_lock:
        _job_state.update(updates)


def _run_command(command, stage, description):
    _set_job_state(stage=stage, message=description)
    _append_job_log(f"$ {' '.join(map(str, command))}")
    process = subprocess.Popen(
        command,
        cwd=PROJECT_DIR,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if process.stdout is None:
        raise RuntimeError(f"Unable to read output from the {stage} command.")
    for line in process.stdout:
        _append_job_log(line)
    return_code = process.wait()
    if return_code != 0:
        raise RuntimeError(f"{description} failed with exit code {return_code}.")


def _training_worker(manifest_path, run_name, architecture, epochs, coverage, runs_directory):
    run_directory = Path(runs_directory).resolve() / run_name
    split_manifest = run_directory / "splits.csv"
    model_directory = run_directory / "model"
    try:
        run_directory.mkdir(parents=True, exist_ok=False)
        _run_command(
            [
                sys.executable,
                str(PROJECT_DIR / "scripts" / "prepare.py"),
                "--manifest",
                str(manifest_path),
                "--out",
                str(split_manifest),
            ],
            "preparing",
            "Validating dataset and creating patient-wise splits",
        )
        _run_command(
            [
                sys.executable,
                str(PROJECT_DIR / "scripts" / "train.py"),
                "--manifest",
                str(split_manifest),
                "--run",
                str(model_directory),
                "--arch",
                architecture,
                "--epochs",
                str(epochs),
            ],
            "training",
            f"Training the {architecture} research model",
        )
        _run_command(
            [
                sys.executable,
                str(PROJECT_DIR / "scripts" / "calibrate.py"),
                "--run",
                str(model_directory),
                "--manifest",
                str(split_manifest),
                "--coverage",
                str(coverage),
            ],
            "calibrating",
            "Calibrating on the reserved calibration split",
        )
        _run_command(
            [
                sys.executable,
                str(PROJECT_DIR / "scripts" / "evaluate.py"),
                "--run",
                str(model_directory),
                "--manifest",
                str(split_manifest),
            ],
            "evaluating",
            "Evaluating once on the held-out test split",
        )
        _set_job_state(
            running=False,
            stage="complete",
            message=f"Training and calibration completed: {run_name}",
            error=None,
        )
        _append_job_log("Training, calibration, and checkpoint verification completed.")
    except Exception as exc:
        logger.exception("Training workflow failed")
        _set_job_state(running=False, stage="failed", message=str(exc), error=str(exc))
        _append_job_log(f"ERROR: {exc}")
        if run_directory.exists() and not (model_directory / "best.pt").exists():
            _append_job_log(
                "Partial output was retained for inspection; choose a different run name to retry."
            )
    finally:
        _job_lock.release()


def create_app(test_config=None):
    instance_path = Path(
        (test_config or {}).get("INSTANCE_PATH", PROJECT_DIR / "instance")
    ).resolve()
    instance_path.mkdir(parents=True, exist_ok=True)
    web_app = Flask(
        __name__,
        instance_path=str(instance_path),
        template_folder=str(PROJECT_DIR / "frontend" / "templates"),
        static_folder=str(PROJECT_DIR / "frontend" / "static"),
    )
    web_app.config.update(
        SECRET_KEY=_ensure_secret_key(instance_path),
        MAX_CONTENT_LENGTH=MAX_REQUEST_BYTES,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("AAROGYADRISHTI_SECURE_COOKIES") == "1",
        APP_ENV=os.environ.get("AAROGYADRISHTI_ENV", "development").lower(),
        PERMANENT_SESSION_LIFETIME=60 * 60 * 8,
        RUNS_DIR=str(PROJECT_DIR / "runs"),
        AUTH_DB=str(instance_path / "auth.sqlite3"),
        AUDIT_LOG=str(instance_path / "inference_audit.jsonl"),
        RESEARCH_INFERENCE_ENABLED=os.environ.get(
            "AAROGYADRISHTI_ENABLE_RESEARCH_INFERENCE"
        ) == "1",
    )
    if test_config:
        web_app.config.update(test_config)
    if (
        web_app.config.get("APP_ENV") == "production"
        and not web_app.config["SESSION_COOKIE_SECURE"]
    ):
        raise RuntimeError("Production requires secure HTTPS session cookies.")
    _initialize_auth(web_app.config["AUTH_DB"])

    @web_app.before_request
    def enforce_authentication_and_csrf():
        if request.endpoint != "static":
            session.setdefault("csrf_token", secrets.token_urlsafe(32))
        if request.method in {"POST", "PUT", "PATCH", "DELETE"} and not _csrf_valid():
            if request.path.startswith("/api/"):
                return jsonify(error="Request verification failed. Refresh the page and retry."), 400
            abort(400)

        if request.endpoint == "static":
            return None

        if not _user_exists(web_app.config["AUTH_DB"]):
            if request.endpoint in {"setup", "setup_post", "signup", "signup_post", "forgot_password", "forgot_password_post"}:
                if not _request_is_local():
                    abort(403)
                return None
            if request.endpoint in {"login", "login_post", "logout"}:
                return redirect(url_for("setup"))
            if request.path.startswith("/api/"):
                return jsonify(error="Create the local administrator account first."), 401
            return redirect(url_for("setup"))

        if request.endpoint in {"setup", "setup_post", "signup", "signup_post", "forgot_password", "forgot_password_post", "login", "login_post"}:
            if request.endpoint in {"setup", "setup_post"}:
                return redirect(url_for("index"))
            if session.get("user_id"):
                return redirect(url_for("index"))
            return None
        if not session.get("user_id"):
            if request.path.startswith("/api/"):
                return jsonify(error="Sign in to continue."), 401
            return redirect(url_for("login", next=request.full_path.rstrip("?")))

        current_user = _current_user(web_app.config["AUTH_DB"])
        if current_user is None:
            session.clear()
            return redirect(url_for("login"))
        admin_only_endpoints = {
            "admin_dashboard",
            "admin_users",
            "training",
            "monitoring",
            "api_train",
            "api_training_status",
            "api_model_registry",
            "api_monitoring",
            "api_admin_users",
            "api_admin_user_role",
            "api_radiologist_review",
        }
        if request.endpoint in admin_only_endpoints and current_user["role"] != "admin":
            if request.path.startswith("/api/"):
                return jsonify(error="Administrator access is required."), 403
            return redirect(url_for("user_dashboard"))

        session.permanent = True
        session.setdefault("csrf_token", secrets.token_urlsafe(32))
        return None

    @web_app.after_request
    def set_security_headers(response):
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' blob: data:; "
            "style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; "
            "object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'"
        )
        return response

    @web_app.get("/setup")
    def setup():
        return render_template("auth.html", mode="setup", csrf_token=session["csrf_token"])

    @web_app.post("/setup")
    def setup_post():
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not _request_is_local():
            abort(403)
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,40}", username):
            return render_template(
                "auth.html",
                mode="setup",
                csrf_token=session["csrf_token"],
                error="Username must be 3â€“40 characters using letters, numbers, dot, dash, or underscore.",
            ), 400
        if len(password) < 12:
            return render_template(
                "auth.html",
                mode="setup",
                csrf_token=session["csrf_token"],
                error="Use a password with at least 12 characters.",
            ), 400
        try:
            with _db_connect(web_app.config["AUTH_DB"]) as connection:
                connection.execute("BEGIN IMMEDIATE")
                if connection.execute("SELECT 1 FROM users LIMIT 1").fetchone():
                    return render_template(
                        "auth.html",
                        mode="setup",
                        csrf_token=session["csrf_token"],
                        error="Administrator setup has already been completed.",
                    ), 409
                connection.execute(
                    "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                    (username, generate_password_hash(password), "admin"),
                )
        except sqlite3.IntegrityError:
            return render_template(
                "auth.html",
                mode="setup",
                csrf_token=session["csrf_token"],
                error="Administrator setup has already been completed.",
            ), 409
        session.clear()
        session["user_id"] = username
        session["role"] = "admin"
        session["csrf_token"] = secrets.token_urlsafe(32)
        session.permanent = True
        return redirect(url_for("index"))

    @web_app.get("/login")
    def login():
        message = request.args.get("message", "").strip()
        return render_template(
            "auth.html",
            mode="login",
            csrf_token=session["csrf_token"],
            error=message or None,
        )

    @web_app.get("/forgot-password")
    def forgot_password():
        return render_template(
            "auth.html",
            mode="forgot",
            csrf_token=session["csrf_token"],
        )

    @web_app.post("/forgot-password")
    def forgot_password_post():
        if not _request_is_local():
            abort(403)
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        password_confirm = request.form.get("password_confirm", "")
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,40}", username):
            return render_template(
                "auth.html", mode="forgot", csrf_token=session["csrf_token"],
                error="Enter a valid username.",
            ), 400
        password_error = _password_policy(password, username)
        if password_error:
            return render_template(
                "auth.html", mode="forgot", csrf_token=session["csrf_token"],
                error=password_error,
            ), 400
        if not hmac.compare_digest(password, password_confirm):
            return render_template(
                "auth.html", mode="forgot", csrf_token=session["csrf_token"],
                error="Passwords do not match.",
            ), 400
        with _db_connect(web_app.config["AUTH_DB"]) as connection:
            result = connection.execute(
                "UPDATE users SET password_hash = ? WHERE username = ?",
                (generate_password_hash(password), username),
            )
        if result.rowcount != 1:
            return render_template(
                "auth.html", mode="forgot", csrf_token=session["csrf_token"],
                error="No local account was found for that username.",
            ), 404
        return redirect(url_for("login", message="Password updated. Sign in with your new password."))

    @web_app.get("/signup")
    def signup():
        return render_template("auth.html", mode="signup", csrf_token=session["csrf_token"])

    @web_app.post("/signup")
    def signup_post():
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        password_confirm = request.form.get("password_confirm", "")
        if not _request_is_local():
            abort(403)
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,40}", username):
            return render_template(
                "auth.html", mode="signup", csrf_token=session["csrf_token"],
                error="Username must be 3â€“40 characters using letters, numbers, dot, dash, or underscore.",
            ), 400
        password_error = _password_policy(password, username)
        if password_error:
            return render_template(
                "auth.html", mode="signup", csrf_token=session["csrf_token"],
                error=password_error,
            ), 400
        if not hmac.compare_digest(password, password_confirm):
            return render_template(
                "auth.html", mode="signup", csrf_token=session["csrf_token"],
                error="Passwords do not match.",
            ), 400
        try:
            with _db_connect(web_app.config["AUTH_DB"]) as connection:
                connection.execute(
                    "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                    (username, generate_password_hash(password), "user"),
                )
        except sqlite3.IntegrityError:
            return render_template(
                "auth.html", mode="signup", csrf_token=session["csrf_token"],
                error="That username is already registered.",
            ), 409
        return redirect(url_for("login", message="Account created. Sign in to continue."))

    @web_app.post("/login")
    def login_post():
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with _db_connect(web_app.config["AUTH_DB"]) as connection:
            user = connection.execute(
                "SELECT username, password_hash, role FROM users WHERE username = ?", (username,)
            ).fetchone()
        if user is None or not check_password_hash(user["password_hash"], password):
            return render_template(
                "auth.html",
                mode="login",
                csrf_token=session["csrf_token"],
                error="Username or password is incorrect.",
            ), 401
        session.clear()
        session["user_id"] = user["username"]
        session["role"] = user["role"]
        session["csrf_token"] = secrets.token_urlsafe(32)
        session.permanent = request.form.get("remember") == "on"
        return redirect(
            url_for("admin_dashboard" if user["role"] == "admin" else "user_dashboard")
        )

    @web_app.post("/logout")
    def logout():
        session.clear()
        return redirect(url_for("login"))

    @web_app.get("/")
    def index():
        current_user = _current_user(web_app.config["AUTH_DB"])
        dashboard = "admin_dashboard.html" if current_user["role"] == "admin" else "user_dashboard.html"
        return render_template(
            dashboard,
            csrf_token=session["csrf_token"],
            username=current_user["username"],
        )

    @web_app.get("/admin-dashboard")
    def admin_dashboard():
        current_user = _current_user(web_app.config["AUTH_DB"])
        return render_template(
            "admin_dashboard.html",
            csrf_token=session["csrf_token"],
            username=current_user["username"],
        )

    @web_app.get("/admin/users")
    def admin_users():
        with _db_connect(web_app.config["AUTH_DB"]) as connection:
            users = connection.execute(
                "SELECT username, role, created_at FROM users ORDER BY created_at, username"
            ).fetchall()
        return render_template(
            "admin_users.html",
            csrf_token=session["csrf_token"],
            username=session["user_id"],
            users=users,
        )

    @web_app.get("/user-dashboard")
    def user_dashboard():
        current_user = _current_user(web_app.config["AUTH_DB"])
        return render_template(
            "user_dashboard.html",
            csrf_token=session["csrf_token"],
            username=current_user["username"],
        )

    @web_app.get("/api/admin/users")
    def api_admin_users():
        with _db_connect(web_app.config["AUTH_DB"]) as connection:
            users = connection.execute(
                "SELECT username, role, created_at FROM users ORDER BY created_at, username"
            ).fetchall()
        return jsonify(users=[dict(user) for user in users])

    @web_app.post("/api/admin/users/<username>/role")
    def api_admin_user_role(username):
        role = request.form.get("role", "").strip().lower()
        if role not in {"admin", "user"}:
            return jsonify(error="Role must be admin or user."), 400
        with _db_connect(web_app.config["AUTH_DB"]) as connection:
            target = connection.execute(
                "SELECT username, role FROM users WHERE username = ?", (username,)
            ).fetchone()
            if target is None:
                return jsonify(error="User not found."), 404
            if target["role"] != "admin" and role == "admin":
                admin_exists = connection.execute(
                    "SELECT 1 FROM users WHERE role = 'admin' LIMIT 1"
                ).fetchone()
                if admin_exists is not None:
                    return jsonify(error="Only one administrator account is allowed."), 409
            if target["role"] == "admin" and role == "user":
                admin_count = connection.execute(
                    "SELECT COUNT(*) AS count FROM users WHERE role = 'admin'"
                ).fetchone()["count"]
                if admin_count <= 1:
                    return jsonify(error="At least one administrator must remain."), 409
            connection.execute(
                "UPDATE users SET role = ? WHERE username = ?", (role, username)
            )
        return jsonify(username=username, role=role)

    @web_app.get("/analysis")
    def analysis():
        current_user = _current_user(web_app.config["AUTH_DB"])
        return render_template(
            "index.html",
            csrf_token=session["csrf_token"],
            username=session["user_id"],
            is_admin=bool(current_user and current_user["role"] == "admin"),
            research_inference_enabled=web_app.config["RESEARCH_INFERENCE_ENABLED"],
        )

    @web_app.get("/training")
    def training():
        return render_template(
            "training.html",
            csrf_token=session["csrf_token"],
            username=session["user_id"],
        )

    @web_app.get("/review-queue")
    def review_queue():
        abort(404)

    @web_app.get("/study")
    def study():
        return render_template(
            "study.html", csrf_token=session["csrf_token"], username=session["user_id"]
        )

    @web_app.get("/monitoring")
    def monitoring():
        return render_template(
            "monitoring.html", csrf_token=session["csrf_token"], username=session["user_id"]
        )

    @web_app.get("/api/models")
    def api_models():
        if not web_app.config["RESEARCH_INFERENCE_ENABLED"]:
            return jsonify(
                enabled=False,
                models=[],
                message=(
                    "Research inference is disabled. It is not approved for clinical use."
                ),
            )

        runs_directory = Path(web_app.config["RUNS_DIR"]).resolve()
        models = []
        if runs_directory.is_dir():
            for run_dir in runs_directory.iterdir():
                model_dir = run_dir / "model"
                if model_dir.is_dir() and (model_dir / "best.pt").is_file() and (
                    model_dir / "calibration.json"
                ).is_file() and (model_dir / "test_report.json").is_file():
                    models.append(run_dir.name)
                elif (run_dir / "best.pt").is_file() and (
                    run_dir / "calibration.json"
                ).is_file() and (run_dir / "test_report.json").is_file():
                    models.append(run_dir.name)
        for model_name in models:
            model_dir = _model_directory(runs_directory, model_name)
            checkpoint_sha = image_digest((model_dir / "best.pt").read_bytes())
            metadata = {}
            for name in ("config.json", "provenance.json", "test_report.json"):
                file_path = model_dir / name
                if file_path.is_file():
                    metadata[name.removesuffix(".json")] = json.loads(
                        file_path.read_text(encoding="utf-8")
                    )
            with _db_connect(web_app.config["AUTH_DB"]) as connection:
                connection.execute(
                    "INSERT OR REPLACE INTO model_registry(model,checkpoint_sha256,metadata_json) VALUES(?,?,?)",
                    (model_name, checkpoint_sha, json.dumps(metadata)),
                )
        return jsonify(enabled=True, models=sorted(models))

    @web_app.get("/api/model-registry")
    def api_model_registry():
        with _db_connect(web_app.config["AUTH_DB"]) as connection:
            rows = connection.execute(
                "SELECT model, checkpoint_sha256, metadata_json, active, registered_at "
                "FROM model_registry ORDER BY model"
            ).fetchall()
        return jsonify(
            models=[
                {
                    "model": row["model"],
                    "checkpoint_sha256": row["checkpoint_sha256"],
                    "metadata": json.loads(row["metadata_json"]),
                    "active": bool(row["active"]),
                    "registered_at": row["registered_at"],
                }
                for row in rows
            ]
        )

    @web_app.get("/api/monitoring")
    def api_monitoring():
        with _db_connect(web_app.config["AUTH_DB"]) as connection:
            totals = connection.execute(
                "SELECT COUNT(*) total, SUM(status='REVIEW_REQUIRED') reviews, "
                "SUM(status='INSUFFICIENT_QUALITY') insufficient FROM monitoring_events"
            ).fetchone()
            models = connection.execute(
                "SELECT model, COUNT(*) count FROM monitoring_events GROUP BY model ORDER BY model"
            ).fetchall()
        return jsonify(
            total_inferences=int(totals["total"] or 0),
            review_required=int(totals["reviews"] or 0),
            insufficient_quality=int(totals["insufficient"] or 0),
            by_model={row["model"]: row["count"] for row in models},
        )

    @web_app.get("/api/review-queue")
    def api_review_queue():
        with _db_connect(web_app.config["AUTH_DB"]) as connection:
            if current_user := _current_user(web_app.config["AUTH_DB"]):
                if current_user["role"] == "admin":
                    rows = connection.execute(
                        "SELECT review_id, study_id, inference_id, model, status, decision, reason, "
                        "reviewed_by, created_at, reviewed_at "
                        "FROM review_queue ORDER BY created_at DESC"
                    ).fetchall()
                else:
                    rows = connection.execute(
                        "SELECT rq.review_id, rq.study_id, rq.inference_id, rq.model, rq.status, "
                        "rq.decision, rq.reason, rq.reviewed_by, rq.created_at, rq.reviewed_at "
                        "FROM review_queue rq "
                        "LEFT JOIN studies s ON s.study_id = rq.study_id "
                        "WHERE rq.owner = ? OR s.user = ? "
                        "ORDER BY rq.created_at DESC",
                        (current_user["username"], current_user["username"]),
                    ).fetchall()
            else:
                rows = []
        return jsonify(items=[dict(row) for row in rows])

    @web_app.post("/api/train")
    def api_train():
        manifest_value = request.form.get("manifest_path", "").strip()
        run_name = request.form.get("run_name", "").strip()
        architecture = request.form.get("architecture", "cnn")
        try:
            epochs = int(request.form.get("epochs", "20"))
        except ValueError:
            return jsonify(error="Epoch count must be a whole number."), 400

        if not manifest_value:
            return jsonify(error="Provide the full path to the dataset manifest CSV."), 400
        if not RUN_NAME_PATTERN.fullmatch(run_name):
            return jsonify(error="Run name must be 1â€“40 letters, numbers, dashes, or underscores."), 400
        if architecture not in SUPPORTED_ARCHITECTURES:
            return jsonify(error="Choose a supported model architecture."), 400
        if not 1 <= epochs <= 100:
            return jsonify(error="Epoch count must be between 1 and 100."), 400

        manifest_path = Path(manifest_value).expanduser().resolve()
        if not manifest_path.is_file() or manifest_path.suffix.lower() != ".csv":
            return jsonify(error="Manifest path must point to an existing .csv file."), 400
        try:
            read_manifest(manifest_path, require_split=False)
        except (OSError, ValueError, KeyError) as exc:
            return jsonify(error=f"Manifest validation failed: {exc}"), 400

        runs_directory = Path(web_app.config["RUNS_DIR"]).resolve()
        runs_directory.mkdir(parents=True, exist_ok=True)
        run_directory = (runs_directory / run_name).resolve()
        if run_directory.parent != runs_directory:
            return jsonify(error="Invalid run output path."), 400
        if run_directory.exists():
            return jsonify(error="That run name already exists. Choose a new run name."), 409
        if not _job_lock.acquire(blocking=False):
            return jsonify(error="Another training job is already running."), 409

        with _job_state_lock:
            _job_state.update(
                running=True,
                stage="queued",
                message="Training workflow queued",
                log=[],
                error=None,
            )
        worker = threading.Thread(
            target=_training_worker,
            args=(manifest_path, run_name, architecture, epochs, 0.9),
            kwargs={"runs_directory": str(runs_directory)},
            daemon=True,
        )
        worker.start()
        return jsonify(message="Training and calibration started.", run_name=run_name), 202

    @web_app.get("/api/training-status")
    def api_training_status():
        with _job_state_lock:
            return jsonify(dict(_job_state))

    @web_app.post("/api/predict")
    def api_predict():
        if not web_app.config["RESEARCH_INFERENCE_ENABLED"]:
            return jsonify(
                error=(
                    "Inference is disabled by default. This project is not clinically "
                    "validated or approved for patient-care use."
                )
            ), 403

        uploaded = request.files.get("image")
        run_name = request.form.get("run_name", "").strip()
        if uploaded is None or not uploaded.filename:
            return jsonify(error="Choose an image to continue."), 400
        if Path(uploaded.filename).suffix.lower() not in ALLOWED_EXTENSIONS:
            return jsonify(error="Upload a PNG or JPEG image."), 415
        if not RUN_NAME_PATTERN.fullmatch(run_name):
            return jsonify(error="Choose a trained, calibrated model first."), 400

        runs_directory = Path(web_app.config["RUNS_DIR"]).resolve()
        try:
            model_directory = _model_directory(runs_directory, run_name)
        except ValueError:
            return jsonify(error="Invalid model selection."), 400

        try:
            image_data = uploaded.stream.read(MAX_UPLOAD_BYTES + 1)
            if len(image_data) > MAX_UPLOAD_BYTES:
                return jsonify(error="File exceeds the 10 MB upload limit."), 413
            with Image.open(BytesIO(image_data)) as source:
                if source.format not in {"PNG", "JPEG"}:
                    return jsonify(error="Upload a PNG or JPEG image."), 415
                if min(source.size) < 32:
                    return jsonify(error="Image dimensions must be at least 32 Ã— 32 pixels."), 400
                if source.width * source.height > MAX_IMAGE_PIXELS:
                    return jsonify(error="Image dimensions exceed the 16-megapixel limit."), 400
                image = source.convert("RGB")
        except (UnidentifiedImageError, OSError, ValueError):
            return jsonify(error="The uploaded file is not a readable image."), 400

        if not (model_directory / "best.pt").is_file() or not (
            model_directory / "calibration.json"
        ).is_file():
            return jsonify(error="Selected model is not trained and calibrated yet."), 404
        if not (model_directory / "test_report.json").is_file():
            return jsonify(error="Selected model has not completed held-out evaluation."), 409

        try:
            model, checkpoint, calibration = _load_predictor(str(model_directory))
            image_tensor = transforms.Compose(
                [
                    transforms.Resize(
                        (checkpoint["config"]["size"], checkpoint["config"]["size"])
                    ),
                    transforms.ToTensor(),
                ]
            )(image).unsqueeze(0)
            result = predict_tensor(model, image_tensor, calibration)
        except (FileNotFoundError, ValueError, KeyError) as exc:
            logger.warning("Model is not ready for inference: %s", exc)
            return jsonify(error="Model files are incomplete or calibration is invalid."), 503
        except Exception:
            logger.exception("Inference failed")
            return jsonify(error="Inference failed. Check the server logs for details."), 500

        inference_id = secrets.token_urlsafe(18)
        review_id = secrets.token_urlsafe(18)
        append_audit_event(
            web_app.config["AUDIT_LOG"],
            {
                "event": "research_inference",
                "inference_id": inference_id,
                "user": session["user_id"],
                "model": run_name,
                "image_sha256": image_digest(image_data),
                "ai_finding": result.get("ai_finding"),
                "status": result.get("status"),
                "mandatory_radiologist_review": True,
            },
        )
        with _db_connect(web_app.config["AUTH_DB"]) as connection:
            connection.execute(
                "INSERT INTO monitoring_events(event,model,status) VALUES(?,?,?)",
                ("inference", run_name, result.get("status")),
            )
            connection.execute(
                "INSERT INTO review_queue(review_id,study_id,inference_id,model,owner) "
                "VALUES(?,?,?,?,?)",
                (review_id, "single-image", inference_id, run_name, session["user_id"]),
            )
        result["inference_id"] = inference_id
        result["review_id"] = review_id
        return jsonify(result)

    @web_app.post("/api/radiologist-review")
    def api_radiologist_review():
        payload = request.get_json(silent=True) or {}
        inference_id = str(payload.get("inference_id", "")).strip()
        decision = str(payload.get("decision", "")).strip().lower()
        reason = str(payload.get("reason", "")).strip()
        allowed_decisions = {"agree", "disagree", "unable_to_assess"}
        if not inference_id or not re.fullmatch(r"[A-Za-z0-9_-]{10,80}", inference_id):
            return jsonify(error="A valid inference review ID is required."), 400
        if decision not in allowed_decisions:
            return jsonify(error="Choose agree, disagree, or unable_to_assess."), 400
        if len(reason) > 500:
            return jsonify(error="Review reason must be 500 characters or fewer."), 400
        with _db_connect(web_app.config["AUTH_DB"]) as connection:
            review = connection.execute(
                "SELECT review_id, status FROM review_queue WHERE inference_id = ?",
                (inference_id,),
            ).fetchone()
            if review is None:
                return jsonify(error="Inference review item was not found."), 404
            if review["status"] == "reviewed":
                return jsonify(error="This inference has already been reviewed."), 409
        append_audit_event(
            web_app.config["AUDIT_LOG"],
            {
                "event": "radiologist_review",
                "inference_id": inference_id,
                "user": session["user_id"],
                "decision": decision,
                "reason": reason,
                "review_id": review["review_id"],
            },
        )
        with _db_connect(web_app.config["AUTH_DB"]) as connection:
            connection.execute(
                "UPDATE review_queue SET status='reviewed', decision=?, reason=?, "
                "reviewed_by=?, reviewed_at=CURRENT_TIMESTAMP "
                "WHERE inference_id=?",
                (decision, reason, session["user_id"], inference_id),
            )
        return jsonify(
            recorded=True,
            inference_id=inference_id,
            review_id=review["review_id"],
            decision=decision,
            reviewed_by=session["user_id"],
            mandatory_radiologist_review=True,
        )

    @web_app.post("/api/study-infer")
    def api_study_infer():
        if not web_app.config["RESEARCH_INFERENCE_ENABLED"]:
            return jsonify(error="Research inference is disabled. It is not approved for clinical use."), 403
        study_id = request.form.get("study_id", "").strip()
        run_name = request.form.get("run_name", "").strip()
        uploads = request.files.getlist("study")
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", study_id):
            return jsonify(error="Use a pseudonymous study ID."), 400
        if not RUN_NAME_PATTERN.fullmatch(run_name) or not uploads or len(uploads) > 64:
            return jsonify(error="Provide a model and 1-64 study images."), 400
        runs_directory = Path(web_app.config["RUNS_DIR"]).resolve()
        try:
            model_directory = _model_directory(runs_directory, run_name)
        except ValueError as exc:
            return jsonify(error=str(exc)), 400
        try:
            model, checkpoint, calibration = _load_predictor(str(model_directory))
            results = []
            for upload in uploads:
                data = upload.stream.read(MAX_UPLOAD_BYTES + 1)
                if len(data) > MAX_UPLOAD_BYTES:
                    raise ValueError("Each study image must be 10 MB or smaller.")
                with Image.open(BytesIO(data)) as source:
                    if source.format not in {"PNG", "JPEG"}:
                        raise ValueError("Study files must be PNG or JPEG.")
                    if min(source.size) < 32 or source.width * source.height > MAX_IMAGE_PIXELS:
                        raise ValueError("Study image dimensions are outside the allowed limits.")
                    image = source.convert("RGB")
                tensor = transforms.Resize(
                    (checkpoint["config"]["size"], checkpoint["config"]["size"])
                )(image)
                tensor = transforms.ToTensor()(tensor).unsqueeze(0)
                result = predict_tensor(model, tensor, calibration)
                result["filename"] = Path(upload.filename).name
                results.append(result)
            summary = aggregate_patient_predictions(results)
        except (FileNotFoundError, ValueError, KeyError) as exc:
            return jsonify(error=str(exc)), 400
        inference_id = secrets.token_urlsafe(18)
        review_id = secrets.token_urlsafe(18)
        with _db_connect(web_app.config["AUTH_DB"]) as connection:
            connection.execute(
                "INSERT OR REPLACE INTO studies(study_id,user,model,status,image_count) VALUES(?,?,?,?,?)",
                (study_id, session["user_id"], run_name, summary["ai_finding"], len(results)),
            )
            connection.execute(
                "INSERT INTO review_queue(review_id,study_id,inference_id,model,owner) "
                "VALUES(?,?,?,?,?)",
                (review_id, study_id, inference_id, run_name, session["user_id"]),
            )
            for result in results:
                connection.execute(
                    "INSERT INTO monitoring_events(event,model,status) VALUES(?,?,?)",
                    ("study_inference", run_name, result.get("status")),
                )
        append_audit_event(
            web_app.config["AUDIT_LOG"],
            {
                "event": "research_study_inference",
                "study_id": study_id,
                "inference_id": inference_id,
                "user": session["user_id"],
                "model": run_name,
                "image_count": len(results),
                "ai_finding": summary["ai_finding"],
                "mandatory_radiologist_review": True,
            },
        )
        return jsonify(
            study_id=study_id,
            review_id=review_id,
            inference_id=inference_id,
            images=results,
            summary=summary,
            explainability_available=True,
            mandatory_radiologist_review=True,
        )

    @web_app.post("/api/explain")
    def api_explain():
        if not web_app.config["RESEARCH_INFERENCE_ENABLED"]:
            return jsonify(error="Research inference is disabled. It is not approved for clinical use."), 403
        run_name = request.form.get("run_name", "").strip()
        upload = request.files.get("image")
        if not upload or not RUN_NAME_PATTERN.fullmatch(run_name):
            return jsonify(error="Provide an image and selected model."), 400
        data = upload.stream.read(MAX_UPLOAD_BYTES + 1)
        if len(data) > MAX_UPLOAD_BYTES:
            return jsonify(error="File exceeds the 10 MB upload limit."), 413
        try:
            with Image.open(BytesIO(data)) as source:
                if source.format not in {"PNG", "JPEG"}:
                    return jsonify(error="Upload a PNG or JPEG image."), 415
                if min(source.size) < 32 or source.width * source.height > MAX_IMAGE_PIXELS:
                    return jsonify(error="Image dimensions are outside the allowed limits."), 400
                image = source.convert("RGB")
            model, checkpoint, _ = _load_predictor(
                str(_model_directory(web_app.config["RUNS_DIR"], run_name))
            )
            tensor = transforms.ToTensor()(
                transforms.Resize((checkpoint["config"]["size"], checkpoint["config"]["size"]))(image)
            ).unsqueeze(0)
            return jsonify(
                model_score=saliency_map(model, tensor),
                warning="Saliency is an exploratory research visualization, not lesion proof.",
            )
        except (OSError, ValueError, KeyError, FileNotFoundError) as exc:
            return jsonify(error=str(exc)), 400

    @web_app.post("/api/validate-study")
    def api_validate_study():
        uploads = request.files.getlist("study")
        if not uploads:
            return jsonify(error="Upload at least one DICOM or NIfTI study file."), 400
        if len(uploads) > 512:
            return jsonify(error="A study may contain at most 512 files."), 400
        files = []
        try:
            for upload in uploads:
                if not upload.filename:
                    continue
                data = upload.stream.read(MAX_UPLOAD_BYTES + 1)
                if len(data) > MAX_UPLOAD_BYTES:
                    raise ValueError("Each medical imaging file must be 10 MB or smaller.")
                metadata = validate_medical_file(data, upload.filename)
                files.append({"filename": Path(upload.filename).name, **metadata})
        except (RuntimeError, ValueError) as exc:
            return jsonify(error=str(exc)), 400
        if not files:
            return jsonify(error="No valid study files were supplied."), 400
        summary = {
            "valid": True,
            "file_count": len(files),
            "formats": sorted({item["format"] for item in files}),
            "files": files,
            "inference_ready": False,
            "warning": (
                "Container validation is not clinical validation. "
                "A governed study adapter and radiologist review are required before inference."
            ),
        }
        append_audit_event(
            web_app.config["AUDIT_LOG"],
            {
                "event": "medical_study_validation",
                "user": session["user_id"],
                "file_count": len(files),
                "formats": summary["formats"],
            },
        )
        return jsonify(summary)

    @web_app.post("/api/patient-summary")
    def api_patient_summary():
        payload = request.get_json(silent=True) or {}
        patient_id = str(payload.get("patient_id", "")).strip()
        predictions = payload.get("predictions")
        if not patient_id or not re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", patient_id):
            return jsonify(error="Provide a pseudonymous patient ID, not a name."), 400
        if not isinstance(predictions, list):
            return jsonify(error="Predictions must be a list."), 400
        try:
            summary = aggregate_patient_predictions(predictions)
        except (KeyError, TypeError, ValueError) as exc:
            return jsonify(error=str(exc)), 400
        summary["patient_id"] = patient_id
        summary["patient_id_warning"] = "Use pseudonymous IDs only; do not enter names or identifiers."
        append_audit_event(
            web_app.config["AUDIT_LOG"],
            {
                "event": "patient_aggregation",
                "user": session["user_id"],
                "patient_id_sha256": image_digest(patient_id.encode("utf-8")),
                "image_count": summary["image_count"],
                "ai_finding": summary["ai_finding"],
            },
        )
        return jsonify(summary)

    @web_app.errorhandler(413)
    def request_too_large(_error):
        return jsonify(error="File exceeds the 10 MB upload limit."), 413

    return web_app


app = create_app()


if __name__ == "__main__":
    if os.environ.get("AAROGYADRISHTI_ENV", "development").lower() == "production":
        raise RuntimeError(
            "Do not run the Flask development server in production; use a WSGI server "
            "behind HTTPS."
        )
    host = os.environ.get("AAROGYADRISHTI_HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "5000"))
    app.run(host=host, port=port, debug=False)

