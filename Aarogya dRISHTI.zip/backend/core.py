﻿"""Shared dataset, model, and image utilities for the research workflow."""

import hashlib
import random
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from PIL import Image
from torch import nn
from torch.utils.data import Dataset
from torchvision import models, transforms
from torchvision.transforms import functional as TF

CLASS_NAMES = ["no_tumor", "tumor"]


def seed_all(seed):
    """Seed the libraries used by training and evaluation."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def sha256_file(path):
    """Return a stable SHA-256 fingerprint for a file on disk."""
    h = hashlib.sha256()
    with open(path, "rb") as file_handle:
        for block in iter(lambda: file_handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_manifest(path, require_split=True):
    """Load and validate the manifest used by the research pipeline."""
    path = Path(path).resolve()
    df = pd.read_csv(path, dtype={'patient_id': str})
    required = {'path', 'label'}
    if require_split:
        required.add('split')
    if not required.issubset(df.columns):
        raise ValueError(f'Required columns: {sorted(required)}')
    group_column = 'group_id' if 'group_id' in df.columns else 'patient_id'
    if group_column not in df.columns:
        raise ValueError('Required grouping column: patient_id or group_id')
    if df[list(required | {group_column})].isna().any().any():
        raise ValueError('Missing manifest values')
    df[group_column] = df[group_column].astype(str).str.strip()
    if group_column == 'patient_id':
        df['group_id'] = df.patient_id
    if (df.group_id == '').any() or not df.label.isin([0, 1]).all():
        raise ValueError('Need non-empty group IDs and labels 0/1')
    df['label'] = df.label.astype(int)
    df['path'] = df.path.map(lambda p: str((path.parent / str(p)).resolve()))
    if df.path.duplicated().any():
        raise ValueError('Repeated image paths')
    if (df.groupby('group_id').label.nunique() > 1).any():
        raise ValueError('Every group must have a consistent label')
    if require_split:
        splits = {'train', 'val', 'cal', 'test'}
        if set(df.split) != splits:
            raise ValueError('Require train/val/cal/test splits')
        if (df.groupby('group_id').split.nunique() > 1).any():
            raise ValueError('Group leakage across splits')
        if any(set(part.label) != {0, 1} for _, part in df.groupby('split')):
            raise ValueError('Both classes required in every split')
    return df

def fingerprint(df):
    """Fingerprint manifest contents and the referenced image bytes."""
    h = hashlib.sha256()
    for row in df.sort_values('path').itertuples():
        if not Path(row.path).is_file():
            raise FileNotFoundError(row.path)
        value = (
            f"{row.path}|{row.label}|{row.group_id}|{row.split}|"
            f"{sha256_file(row.path)}\n"
        )
        h.update(value.encode())
    return h.hexdigest()

class MRIDataset(Dataset):
    def __init__(self, df, size=224, train=False):
        self.df = df.reset_index(drop=True)
        ops = [transforms.Resize((size, size))]
        if train:
            ops.append(transforms.RandomRotation(5))
        ops.append(transforms.ToTensor())
        self.transform = transforms.Compose(ops)
    def __len__(self):
        return len(self.df)
    def __getitem__(self, index):
        row = self.df.iloc[index]
        with Image.open(row.path) as img:
            x = self.transform(img.convert('RGB'))
        return x, torch.tensor(int(row.label), dtype=torch.long)

def load_image(path, size):
    with Image.open(path) as img:
        return transforms.Compose([
            transforms.Resize((size, size)), transforms.ToTensor()
        ])(img.convert('RGB')).unsqueeze(0)

SUPPORTED_ARCHITECTURES = ("cnn", "resnet50", "efficientnet_b0")


class MRIModel(nn.Module):
    """Build one of the supported 2D research comparison architectures."""

    def __init__(self, arch='cnn', pretrained=False):
        super().__init__()
        self.register_buffer('mean', torch.tensor([.485, .456, .406]).view(1,3,1,1))
        self.register_buffer('std', torch.tensor([.229, .224, .225]).view(1,3,1,1))
        if arch == 'cnn':
            self.net = nn.Sequential(
                nn.Conv2d(3, 16, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
                nn.Conv2d(16, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
                nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(),
                nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Dropout(.2), nn.Linear(64, 2))
        elif arch == 'resnet50':
            self.net = models.resnet50(weights=models.ResNet50_Weights.DEFAULT if pretrained else None)
            self.net.fc = nn.Linear(self.net.fc.in_features, 2)
        elif arch == "efficientnet_b0":
            self.net = models.efficientnet_b0(
                weights=(
                    models.EfficientNet_B0_Weights.DEFAULT
                    if pretrained
                    else None
                )
            )
            self.net.classifier[-1] = nn.Linear(
                self.net.classifier[-1].in_features, 2
            )
        else:
            raise ValueError(
                f"Unknown architecture {arch!r}; choose from {SUPPORTED_ARCHITECTURES}."
            )
    def forward(self, x):
        return self.net((x - self.mean) / self.std)

def perturb_views(x):
    return [x, TF.adjust_gamma(x, .9), TF.adjust_gamma(x, 1.1),
            TF.gaussian_blur(x, [3, 3], [.5, .5])]

def load_run(run, device='cpu'):
    checkpoint = torch.load(Path(run) / 'best.pt', map_location=device, weights_only=True)
    model = MRIModel(checkpoint['config']['arch']).to(device)
    model.load_state_dict(checkpoint['state'])
    model.eval()
    return model, checkpoint

