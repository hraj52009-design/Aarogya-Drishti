﻿import numpy as np
import torch


def saliency_map(model, image_tensor):
    """Return a small normalized gradient map; never represents a clinical lesion mask."""
    x = image_tensor.detach().clone().requires_grad_(True)
    model.zero_grad(set_to_none=True)
    score = model(x)[0, 1]
    score.backward()
    gradient = x.grad.detach().abs().mean(dim=1)[0].cpu().numpy()
    gradient -= gradient.min()
    maximum = gradient.max()
    if maximum:
        gradient /= maximum
    return {
        "width": int(gradient.shape[1]),
        "height": int(gradient.shape[0]),
        "values": np.round(gradient, 4).tolist(),
    }

