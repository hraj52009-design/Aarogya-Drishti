﻿"""Validate medical imaging containers without persisting source files."""

from io import BytesIO
from pathlib import Path

import numpy as np



SUPPORTED_MEDICAL_EXTENSIONS = {".dcm", ".dicom", ".nii", ".gz"}
_PHI_TAGS = {
    "PatientName",
    "PatientID",
    "PatientBirthDate",
    "PatientSex",
    "AccessionNumber",
    "InstitutionName",
    "ReferringPhysicianName",
    "StudyID",
}


def _require_dependencies():
    try:
        import nibabel as nib
        import pydicom
    except ImportError as exc:
        raise RuntimeError(
            "DICOM/NIfTI support requires pydicom and nibabel to be installed."
        ) from exc
    return nib, pydicom


def validate_dicom(data):
    _, pydicom = _require_dependencies()
    try:
        dataset = pydicom.dcmread(BytesIO(data), force=False, stop_before_pixels=True)
    except (pydicom.errors.InvalidDicomError, OSError, ValueError) as exc:
        raise ValueError("The uploaded DICOM file is invalid or unreadable.") from exc
    present_phi = sorted(
        tag for tag in _PHI_TAGS if getattr(dataset, tag, None) not in (None, "")
    )
    if present_phi:
        raise ValueError(
            "DICOM contains identifying metadata. De-identify it before upload: "
            + ", ".join(present_phi)
        )
    rows = int(getattr(dataset, "Rows", 0) or 0)
    columns = int(getattr(dataset, "Columns", 0) or 0)
    if rows < 32 or columns < 32:
        raise ValueError("DICOM image dimensions must be at least 32 x 32 pixels.")
    return {
        "format": "DICOM",
        "rows": rows,
        "columns": columns,
        "modality": str(getattr(dataset, "Modality", "")),
        "series_uid_present": bool(getattr(dataset, "SeriesInstanceUID", None)),
        "phi_detected": False,
    }


def validate_nifti(data, filename):
    nib, _ = _require_dependencies()
    try:
        file_map = nib.Nifti1Image.make_file_map()
        file_map["image"].fileobj = BytesIO(data)
        image = nib.Nifti1Image.from_file_map(file_map)
    except (nib.filebasedimages.ImageFileError, ValueError, OSError) as exc:
        raise ValueError("The uploaded NIfTI file is invalid or unreadable.") from exc
    shape = tuple(int(value) for value in image.shape)
    if len(shape) not in {3, 4} or min(shape[:3]) < 8:
        raise ValueError("NIfTI must contain a 3D volume with adequate dimensions.")
    if not np.isfinite(np.asarray(image.header.get_zooms()[:3])).all():
        raise ValueError("NIfTI voxel spacing is invalid.")
    return {
        "format": "NIfTI",
        "shape": shape,
        "filename": Path(filename).name,
        "phi_detected": False,
        "note": "NIfTI volume validated in memory; model inference still requires a governed study adapter.",
    }


def validate_medical_file(data, filename):
    name = Path(filename).name.lower()
    if name.endswith((".nii", ".nii.gz")):
        return validate_nifti(data, name)
    if name.endswith((".dcm", ".dicom")):
        return validate_dicom(data)
    raise ValueError("Supported medical formats are DICOM (.dcm/.dicom) and NIfTI (.nii/.nii.gz).")

