﻿"""Metrics used for descriptive research evaluation reports."""

import numpy as np
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, average_precision_score, confusion_matrix,
                             log_loss)


def threshold_metrics(y, p, threshold):
    y, p = np.asarray(y), np.asarray(p)
    if not len(y):
        return {"n": 0, "threshold": float(threshold), "note": "No samples"}
    pred = (p >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {
        "n": int(len(y)),
        "threshold": float(threshold),
        "sensitivity": float(tp / (tp + fn)) if tp + fn else None,
        "specificity": float(tn / (tn + fp)) if tn + fp else None,
        "false_negative_count": int(fn),
        "false_positive_count": int(fp),
        "confusion_matrix_tn_fp_fn_tp": [int(tn), int(fp), int(fn), int(tp)],
    }


def prevalence_metrics(y, p, threshold, prevalences=(0.01, 0.05, 0.10, 0.20)):
    operating = threshold_metrics(y, p, threshold)
    sensitivity = operating["sensitivity"]
    specificity = operating["specificity"]
    values = {}
    for prevalence in prevalences:
        if sensitivity is None or specificity is None:
            values[str(prevalence)] = {"ppv": None, "npv": None}
            continue
        ppv = sensitivity * prevalence / (
            sensitivity * prevalence + (1 - specificity) * (1 - prevalence)
        )
        npv = specificity * (1 - prevalence) / (
            (1 - sensitivity) * prevalence + specificity * (1 - prevalence)
        )
        values[str(prevalence)] = {"ppv": float(ppv), "npv": float(npv)}
    return values


def calibration_curve(y, p, bins=10):
    y, p = np.asarray(y), np.asarray(p)
    rows = []
    for low, high in zip(np.linspace(0, 1, bins + 1)[:-1], np.linspace(0, 1, bins + 1)[1:]):
        mask = (p >= low) & ((p <= high) if high == 1 else (p < high))
        if mask.any():
            rows.append({
                "lower": float(low),
                "upper": float(high),
                "n": int(mask.sum()),
                "mean_predicted": float(p[mask].mean()),
                "observed_rate": float(y[mask].mean()),
            })
    return rows

def metrics(y, p):
    y, p = np.asarray(y), np.asarray(p)
    if not len(y):
        return {'n': 0, 'note': 'No retained samples; performance undefined'}
    pred = (p >= .5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0,1]).ravel()
    confidence = np.maximum(p, 1-p)
    correct = pred == y
    ece = 0.
    for lo, hi in zip(np.linspace(0,1,16)[:-1], np.linspace(0,1,16)[1:]):
        mask = (confidence >= lo) & ((confidence <= hi) if hi == 1 else (confidence < hi))
        if mask.any():
            ece += float(mask.mean() * abs(correct[mask].mean() - confidence[mask].mean()))
    both = len(np.unique(y)) == 2
    return {'n': len(y), 'accuracy': float(accuracy_score(y,pred)),
            'precision_tumor': float(precision_score(y,pred,zero_division=0)),
            'recall_tumor': float(recall_score(y,pred,zero_division=0)) if tp+fn else None,
            'specificity': float(tn/(tn+fp)) if tn+fp else None,
            'f1_tumor': float(f1_score(y,pred,zero_division=0)),
            'macro_f1': float(f1_score(y,pred,labels=[0,1],average='macro',zero_division=0)),
            'roc_auc': float(roc_auc_score(y,p)) if both else None,
            'average_precision_tumor': float(average_precision_score(y,p)) if both else None,
            'brier': float(np.mean((p-y)**2)), 'ece_15_bins': ece,
            'nll': float(log_loss(y,np.column_stack([1-p,p]),labels=[0,1])),
            'confusion_matrix_tn_fp_fn_tp': [int(tn),int(fp),int(fn),int(tp)]}

def cluster_bootstrap(y, p, groups, repeats=500, seed=42):
    groups = np.asarray(groups)
    unique = np.unique(groups)
    rng = np.random.default_rng(seed)
    indices = {g: np.flatnonzero(groups == g) for g in unique}
    values = {'macro_f1': [], 'roc_auc': []}
    skipped = 0
    for _ in range(repeats):
        idx = np.concatenate([indices[g] for g in rng.choice(unique,len(unique),replace=True)])
        if len(np.unique(y[idx])) < 2:
            skipped += 1
            continue
        m = metrics(y[idx],p[idx])
        for key in values:
            values[key].append(m[key])
    return {'method': '95% percentile group-cluster bootstrap of image-level metrics',
            'requested_resamples': repeats, 'skipped_single_class': skipped,
            'intervals': {k: np.quantile(v,[.025,.975]).tolist() if v else None for k,v in values.items()}}

