﻿"""Run a conservative, research-only prediction on an approved image."""

import argparse
import json
import os
from pathlib import Path
import torch
from .core import CLASS_NAMES, load_image, load_run, perturb_views
from .selective import probability_and_score, load_calibration
from .safety import assess_tensor_quality

@torch.no_grad()
def predict_tensor(model, x, cal):
    """Return a safety-oriented result for one image tensor."""
    quality = assess_tensor_quality(x)
    if not quality["accepted"]:
        return {
            "status": "INSUFFICIENT_QUALITY",
            "ai_finding": "INSUFFICIENT_QUALITY",
            "label": None,
            "tumor_model_probability": None,
            "review_score": 1.0,
            "quality": quality,
            "mandatory_radiologist_review": True,
            "warning": "Image quality or input domain is insufficient. Obtain a suitable MRI image.",
        }
    views = [x] if cal['single_view'] else perturb_views(x)
    logits = torch.stack([model(view) for view in views],1)
    probs, scores = probability_and_score(logits,cal['temperature'],cal['alpha'])
    p, score = float(probs[0,1]), float(scores[0])
    suspicious_threshold = float(cal.get("suspicious_threshold", 0.35))
    unstable = score > cal["threshold"]
    finding = "SUSPICIOUS" if p >= suspicious_threshold else "NOT_SUSPICIOUS"
    return {
        "status": "REVIEW_REQUIRED" if unstable else "RESEARCH_PREDICTION",
        "ai_finding": finding,
        "label": CLASS_NAMES[int(p >= .5)],
        "tumor_model_probability": p,
        "review_score": score,
        "suspicious_threshold": suspicious_threshold,
        "quality": quality,
        "mandatory_radiologist_review": True,
        "warning": (
            "Unvalidated image-level research output. This is not a diagnosis; "
            "a radiologist must review the complete study."
        ),
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--image", required=True)
    args = parser.parse_args()
    if os.environ.get("AAROGYADRISHTI_ENABLE_RESEARCH_INFERENCE") != "1":
        parser.error(
            'inference is disabled by default; enable only for authorized internal '
            'research, never for clinical or patient-care use'
        )
    calibration = load_calibration(args.run)
    model, checkpoint = load_run(args.run)
    image_tensor = load_image(args.image, checkpoint["config"]["size"])
    print(json.dumps(predict_tensor(model, image_tensor, calibration), indent=2))

if __name__ == '__main__':
    main()

