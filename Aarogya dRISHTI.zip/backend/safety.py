﻿"""Safety-oriented helpers for research-only model outputs."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import numpy as np


def assess_tensor_quality(image_tensor):
    """Return conservative image-quality/domain checks for a single RGB tensor."""
    values = image_tensor.detach().cpu().float().numpy()[0]
    gray = values.mean(axis=0)
    contrast = float(gray.std() * 255)
    dynamic_range = float((gray.max() - gray.min()) * 255)
    channel_spread = float(values.std(axis=0).mean() * 255)
    reasons = []
    if contrast < 8 or dynamic_range < 20:
        reasons.append("Image contrast is too low for a reliable research output.")
    if channel_spread > 35:
        reasons.append("Image is outside the grayscale MRI input profile.")
    quality_score = float(np.clip((contrast / 45) * 0.7 + (dynamic_range / 180) * 0.3, 0, 1))
    domain_score = float(np.clip(1 - channel_spread / 70, 0, 1))
    accepted = not reasons and quality_score >= 0.35 and domain_score >= 0.5
    return {
        "accepted": accepted,
        "quality_score": quality_score,
        "domain_score": domain_score,
        "reasons": reasons,
    }


def append_audit_event(path, event):
    """Append metadata only; image bytes and raw patient identifiers are never logged."""
    record = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        **event,
    }
    audit_path = Path(path)
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    with audit_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")


def image_digest(image_data):
    return hashlib.sha256(image_data).hexdigest()


def aggregate_patient_predictions(predictions, threshold=0.35):
    """Conservatively aggregate slice/image findings to a patient-level review queue."""
    if not predictions:
        raise ValueError("At least one image prediction is required.")
    if any(item.get("status") == "INSUFFICIENT_QUALITY" for item in predictions):
        finding = "INSUFFICIENT_QUALITY"
    else:
        probability = max(float(item["tumor_model_probability"]) for item in predictions)
        finding = "SUSPICIOUS" if probability >= threshold else "NOT_SUSPICIOUS"
    return {
        "ai_finding": finding,
        "image_count": len(predictions),
        "max_tumor_model_score": max(
            float(item["tumor_model_probability"]) for item in predictions
        ),
        "mandatory_radiologist_review": True,
        "warning": (
            "Patient-level aggregation is a research triage aid only. "
            "A radiologist must review the complete study."
        ),
    }

