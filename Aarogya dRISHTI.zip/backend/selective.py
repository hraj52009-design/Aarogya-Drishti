﻿"""Calibration and stability scoring helpers for selective prediction."""

import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader
from .core import MRIDataset, perturb_views, sha256_file

@torch.no_grad()
def collect(model, df, size, device, batch=16):
    """Collect logits from the configured perturbation views."""
    chunks, labels = [], []
    loader = DataLoader(MRIDataset(df, size), batch_size=batch, shuffle=False)
    for x, y in loader:
        x = x.to(device)
        chunks.append(torch.stack([model(view) for view in perturb_views(x)], 1).cpu())
        labels.append(y)
    return torch.cat(chunks), torch.cat(labels)

def probability_and_score(logits, temperature, alpha=.5):
    """Convert view logits into probabilities and a review score."""
    probabilities = (logits / temperature).softmax(-1)
    mean = probabilities.mean(1)
    entropy, disagreement = uncertainty_components(probabilities)
    score = (alpha * entropy + (1-alpha) * disagreement).clamp(0,1)
    return mean, score


def uncertainty_components(probabilities):
    """Return normalized predictive entropy and view disagreement."""
    mean = probabilities.mean(1)
    entropy = -(mean * mean.clamp_min(1e-8).log()).sum(1) / np.log(2)
    disagreement = 4 * probabilities[:, :, 1].var(1, unbiased=False)
    return entropy.clamp(0, 1), disagreement.clamp(0, 1)


def uncertainty_summary(logits, temperature, threshold, alpha=0.5):
    """Summarize uncertainty and abstention decisions for a batch."""
    probabilities = (logits / temperature).softmax(-1)
    entropy, disagreement = uncertainty_components(probabilities)
    score = (alpha * entropy + (1 - alpha) * disagreement).clamp(0, 1)
    retained = score <= threshold
    return {
        "mean_entropy": float(entropy.mean()),
        "mean_view_disagreement": float(disagreement.mean()),
        "mean_review_score": float(score.mean()),
        "review_threshold": float(threshold),
        "retained_count": int(retained.sum()),
        "review_count": int((~retained).sum()),
        "retained_fraction": float(retained.float().mean()),
        "note": (
            "Entropy and view disagreement are research uncertainty signals; "
            "they are not calibrated probabilities of disease or safety."
        ),
    }


def load_calibration(run):
    """Load calibration metadata and verify its checkpoint fingerprint."""
    run = Path(run)
    cal = json.loads((run / 'calibration.json').read_text())
    if sha256_file(run / 'best.pt') != cal['checkpoint_sha256']:
        raise ValueError('Checkpoint changed: calibration no longer valid')
    return cal

