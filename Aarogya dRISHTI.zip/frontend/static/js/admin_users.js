const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
const roleError = document.querySelector("#user-management-error");

document.querySelectorAll("[data-role-select]").forEach(function (select) {
  select.addEventListener("change", async function () {
    const row = select.closest("[data-username]");
    const username = row.dataset.username;
    const response = await fetch("/api/admin/users/" + encodeURIComponent(username) + "/role", {
      method: "POST",
      headers: {"Content-Type": "application/x-www-form-urlencoded", "X-CSRFToken": csrfToken},
      body: new URLSearchParams({role: select.value})
    });
    if (!response.ok) {
      const data = await response.json();
      roleError.textContent = data.error || "Could not update role.";
      roleError.hidden = false;
      window.location.reload();
    }
  });
});
