(() => {
  const fileInput = document.querySelector("#image-input");
  const dropzone = document.querySelector("#dropzone");
  const dropContent = document.querySelector("#drop-content");
  const previewWrap = document.querySelector("#preview-wrap");
  const preview = document.querySelector("#image-preview");
  const selectedFile = document.querySelector("#selected-file");
  const fileName = document.querySelector("#file-name");
  const fileSize = document.querySelector("#file-size");
  const consent = document.querySelector("#consent");
  const modelSelect = document.querySelector("#model-select");
  const modelSelectHint = document.querySelector("#model-select-hint");
  const analyzeButton = document.querySelector("#analyze-button");
  const uploadError = document.querySelector("#upload-error");
  const modelStatusCard = document.querySelector("#model-status-card");
  const modelStatusTitle = document.querySelector("#model-status-title");
  const modelStatusDetail = document.querySelector("#model-status-detail");
  const explainButton = document.querySelector("#explain-button");
  const explainError = document.querySelector("#explain-error");
  const saliencyWrap = document.querySelector("#saliency-wrap");
  const saliencyCanvas = document.querySelector("#saliency-canvas");
  const researchInferenceEnabled = document.body.dataset.researchInferenceEnabled === "true";
  const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
  let currentFile = null;
  let previewUrl = null;
  let lastResult = null;
  let analysisRunning = false;

  const showError = (message) => {
    uploadError.textContent = message;
    uploadError.hidden = !message;
  };

  const updateButton = () => {
    analyzeButton.disabled = !(currentFile && consent.checked && modelSelect.value);
  };

  const rejectFile = (message) => {
    clearFile();
    showError(message);
  };

  const resetResults = () => {
    document.querySelector("#results-content").hidden = true;
    document.querySelector("#empty-state").hidden = false;
    const state = document.querySelector("#result-state");
    state.className = "result-state";
    state.innerHTML = '<span class="state-dot"></span> AWAITING IMAGE';
  };

  const setFile = (file) => {
    showError("");
    if (!file) return;
    const allowed = ["image/png", "image/jpeg"];
    if (!allowed.includes(file.type) || !/\.(png|jpe?g)$/i.test(file.name)) {
      rejectFile("Please select a PNG or JPEG image.");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      rejectFile("This file is larger than the 10 MB limit.");
      return;
    }
    if (file.size === 0) {
      rejectFile("The selected file is empty.");
      return;
    }

    currentFile = file;
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = URL.createObjectURL(file);
    preview.src = previewUrl;
    dropContent.hidden = true;
    previewWrap.hidden = false;
    selectedFile.hidden = false;
    fileName.textContent = file.name;
    fileSize.textContent = `${(file.size / 1024).toFixed(0)} KB`;
    resetResults();
    updateButton();
  };

  const clearFile = () => {
    currentFile = null;
    fileInput.value = "";
    preview.removeAttribute("src");
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = null;
    previewWrap.hidden = true;
    dropContent.hidden = false;
    selectedFile.hidden = true;
    showError("");
    resetResults();
    updateButton();
  };

  fileInput.addEventListener("change", () => setFile(fileInput.files[0]));
  dropzone.addEventListener("click", (event) => {
    if (!event.target.closest("#remove-file")) fileInput.click();
  });
  dropzone.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      fileInput.click();
    }
  });
  document.querySelector("#remove-file").addEventListener("click", clearFile);
  consent.addEventListener("change", updateButton);
  modelSelect.addEventListener("change", updateButton);

  fetch("/api/models")
    .then(async (response) => {
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Model list unavailable.");
      modelSelect.replaceChildren();
      if (!payload.enabled) {
        modelSelect.add(new Option("Research inference disabled", ""));
        modelSelectHint.textContent = payload.message;
        return;
      }
      if (payload.models.length === 0) {
        modelSelect.add(new Option("No trained model available", ""));
        modelSelectHint.textContent = "No completed research run is available. Use Model setup to create one.";
        return;
      }
      payload.models.forEach((name) => modelSelect.add(new Option(name, name)));
      modelSelect.disabled = false;
      modelStatusCard.hidden = false;
      modelStatusTitle.textContent = `${payload.models.length} evaluated model${payload.models.length === 1 ? "" : "s"} available`;
      modelStatusDetail.textContent = "Checkpoint, calibration, and held-out evaluation verified.";
      modelSelectHint.textContent = "Only completed runs with checkpoint, calibration, and test report are listed.";
      updateButton();
    })
    .catch((error) => {
      modelSelectHint.textContent = error.message;
    });

  ["dragenter", "dragover"].forEach((name) => {
    dropzone.addEventListener(name, (event) => {
      event.preventDefault();
      dropzone.classList.add("dragging");
    });
  });
  ["dragleave", "drop"].forEach((name) => {
    dropzone.addEventListener(name, (event) => {
      event.preventDefault();
      dropzone.classList.remove("dragging");
    });
  });
  dropzone.addEventListener("drop", (event) => {
    setFile(event.dataTransfer.files[0]);
  });
  const formatProbability = (value) => Math.max(0, Math.min(100, value * 100));

  const showResult = (result) => {
    lastResult = result;
    document.querySelector("#empty-state").hidden = true;
    document.querySelector("#results-content").hidden = false;
    const review = result.status === "REVIEW_REQUIRED";
    const banner = document.querySelector("#prediction-banner");
    banner.classList.toggle("review", review);
    document.querySelector("#prediction-symbol").textContent = review ? "!" : "✓";
    document.querySelector("#prediction-overline").textContent = "AI SAFETY FINDING";
    document.querySelector("#prediction-label").textContent =
      result.ai_finding === "INSUFFICIENT_QUALITY"
        ? "Insufficient quality / out of domain"
        : result.ai_finding === "SUSPICIOUS"
          ? "Suspicious — radiologist review required"
          : "Not suspicious — radiologist review required";
    document.querySelector("#prediction-caption").textContent =
      result.ai_finding === "INSUFFICIENT_QUALITY"
        ? "Use a suitable MRI image and repeat the acquisition."
        : "Research triage output; not a diagnosis.";
    banner.classList.toggle("review", true);
    document.querySelector("#prediction-symbol").textContent = "!";
    document.querySelector("#probability-value").textContent =
      formatProbability(Number(result.tumor_model_probability || 0)).toFixed(1);
    document.querySelector("#probability-meter").style.width =
      `${formatProbability(Number(result.tumor_model_probability || 0))}%`;
    document.querySelector("#stability-value").textContent =
      Number(result.review_score || 1).toFixed(3);
    document.querySelector("#stability-meter").style.width =
      `${formatProbability(result.review_score)}%`;
    document.querySelector("#result-warning p").textContent = result.warning;
    const quality = result.quality || {};
    document.querySelector("#quality-value").textContent = quality.accepted ? "PASS" : "REJECT";
    document.querySelector("#quality-detail").textContent = `Score ${Number(quality.quality_score || 0).toFixed(2)}`;
    document.querySelector("#domain-value").textContent = `${(Number(quality.domain_score || 0) * 100).toFixed(0)}%`;
    document.querySelector("#domain-detail").textContent = quality.reasons?.length ? quality.reasons[0] : "Grayscale profile match";
    document.querySelector("#threshold-value").textContent = result.suspicious_threshold ? `${(result.suspicious_threshold * 100).toFixed(0)}%` : "—";
    saliencyWrap.hidden = true;
    explainError.hidden = true;
    explainButton.disabled = false;
    document.querySelector("#output-timestamp").textContent =
      new Intl.DateTimeFormat(undefined, { hour: "2-digit", minute: "2-digit" }).format(new Date());
    const state = document.querySelector("#result-state");
    state.className = "result-state done";
    state.innerHTML = '<span class="state-dot"></span> MODEL CHECK COMPLETE';
  };

  const renderSaliency = (map) => {
    const context = saliencyCanvas.getContext("2d");
    const image = context.createImageData(map.width, map.height);
    map.values.flat().forEach((value, index) => {
      const intensity = Math.round(Math.max(0, Math.min(1, value)) * 255);
      image.data[index * 4] = intensity;
      image.data[index * 4 + 1] = Math.max(0, 180 - intensity / 2);
      image.data[index * 4 + 2] = 40;
      image.data[index * 4 + 3] = 210;
    });
    const buffer = document.createElement("canvas");
    buffer.width = map.width; buffer.height = map.height;
    buffer.getContext("2d").putImageData(image, 0, 0);
    context.clearRect(0, 0, saliencyCanvas.width, saliencyCanvas.height);
    context.drawImage(buffer, 0, 0, saliencyCanvas.width, saliencyCanvas.height);
    saliencyWrap.hidden = false;
  };

  explainButton.addEventListener("click", async () => {
    if (!currentFile || !modelSelect.value || !lastResult) return;
    explainButton.disabled = true;
    explainError.hidden = true;
    try {
      const body = new FormData();
      body.append("image", currentFile);
      body.append("run_name", modelSelect.value);
      const response = await fetch("/api/explain", {method: "POST", body, headers: {"X-CSRFToken": csrfToken}});
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Explainability map could not be generated.");
      renderSaliency(payload.model_score);
    } catch (error) {
      explainError.textContent = error.message;
      explainError.hidden = false;
    } finally {
      explainButton.disabled = false;
    }
  });

  analyzeButton.addEventListener("click", async () => {
    if (analysisRunning || !researchInferenceEnabled || !currentFile || !consent.checked) return;
    analysisRunning = true;
    showError("");
    analyzeButton.disabled = true;
    analyzeButton.classList.add("loading");
    analyzeButton.querySelector(".button-label").textContent = "Running model check…";
    const state = document.querySelector("#result-state");
    state.className = "result-state";
    state.innerHTML = '<span class="state-dot"></span> PROCESSING';

    try {
      const body = new FormData();
      body.append("image", currentFile);
      body.append("run_name", modelSelect.value);
      const response = await fetch("/api/predict", {
        method: "POST",
        body,
        headers: { "X-CSRFToken": csrfToken },
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Analysis could not be completed.");
      showResult(payload);
    } catch (error) {
      resetResults();
      state.className = "result-state error";
      state.innerHTML = '<span class="state-dot"></span> ANALYSIS FAILED';
      showError(error.message || "Could not reach the local analysis service.");
    } finally {
      analysisRunning = false;
      analyzeButton.classList.remove("loading");
      analyzeButton.querySelector(".button-label").textContent = "Run model check";
      updateButton();
    }
  });

  window.addEventListener("beforeunload", () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
  });
})();
