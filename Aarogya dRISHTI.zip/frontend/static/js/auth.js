(function () {
  "use strict";

  document.querySelectorAll("[data-password-toggle], [data-password-toggle-for]").forEach(function (toggle) {
    var targetId = toggle.getAttribute("data-password-toggle-for") || "password";
    var password = document.getElementById(targetId);
    if (!password) {
      return;
    }
    toggle.addEventListener("click", function () {
      var isVisible = password.type === "text";
      password.type = isVisible ? "password" : "text";
      toggle.setAttribute("aria-pressed", String(!isVisible));
      toggle.setAttribute("aria-label", isVisible ? "Show password" : "Hide password");
    });
  });
}());
