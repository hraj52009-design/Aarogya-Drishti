(async function loadMonitoring() {
  const root = document.querySelector("#monitoring");
  if (!root) return;
  try {
    const response = await fetch("/api/monitoring");
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Unable to load monitoring data.");
    const models = Object.entries(data.by_model)
      .map(([model, count]) => `<li><strong>${escapeHtml(model)}</strong><span>${count} inference${count === 1 ? "" : "s"}</span></li>`)
      .join("");
    root.innerHTML = `<div class="monitoring-summary">
      <div><strong>${data.total_inferences}</strong><small>Total inferences</small></div>
      <div><strong>${data.review_required}</strong><small>Review required</small></div>
      <div><strong>${data.insufficient_quality}</strong><small>Quality flags</small></div>
    </div><ul class="monitoring-models">${models || "<li>No model activity yet.</li>"}</ul>`;
  } catch (error) {
    root.textContent = error.message;
  }
})();

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[character]));
}
