const studyForm = document.querySelector("#study-form");
const studyResult = document.querySelector("#result");
const studyModel = document.querySelector("#model");

async function loadStudyModels() {
  const response = await fetch("/api/models");
  const data = await response.json();
  if (!data.enabled || !data.models.length) {
    studyModel.add(new Option("No completed model available", ""));
    studyModel.disabled = true;
    return;
  }
  data.models.forEach((name) => studyModel.add(new Option(name, name)));
}

studyForm?.addEventListener("submit", async (event) => {
  event.preventDefault();
  studyResult.textContent = "Running study triage…";
  const response = await fetch("/api/study-infer", {
    method: "POST",
    headers: { "X-CSRFToken": document.querySelector('meta[name="csrf-token"]').content },
    body: new FormData(studyForm),
  });
  const data = await response.json();
  studyResult.textContent = JSON.stringify(data, null, 2);
});

loadStudyModels().catch((error) => {
  studyResult.textContent = error.message;
});
