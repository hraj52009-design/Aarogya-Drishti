(() => {
  const form = document.querySelector("#training-form");
  const confirmation = document.querySelector("#data-confirmation");
  const submitButton = document.querySelector("#start-training");
  const errorBox = document.querySelector("#training-error");
  const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
  let pollingTimer = null;

  const showError = (message) => {
    errorBox.textContent = message;
    errorBox.hidden = !message;
  };

  const updateSubmit = () => {
    submitButton.disabled = !confirmation.checked || Boolean(pollingTimer);
  };
  confirmation.addEventListener("change", updateSubmit);

  const updateJob = (job) => {
    document.querySelector("#job-title").textContent =
      job.stage === "complete" ? "Training complete" :
        job.stage === "failed" ? "Workflow stopped" :
          job.running ? "Workflow in progress" : "Ready when you are";
    document.querySelector("#job-message").textContent = job.message;
    const badge = document.querySelector("#job-state");
    const badgeText = job.stage === "complete" ? "COMPLETE" :
      job.stage === "failed" ? "FAILED" :
        job.running ? job.stage.toUpperCase() : "IDLE";
    badge.className = `result-state${job.stage === "complete" ? " done" : job.stage === "failed" ? " error" : ""}`;
    badge.innerHTML = `<span class="state-dot"></span> ${badgeText}`;
    document.querySelector("#job-log").textContent =
      job.log.length ? job.log.join("") : "No training job has been started.";
    document.querySelector("#job-log").scrollTop = document.querySelector("#job-log").scrollHeight;
    document.querySelectorAll(".workflow-step").forEach((step) => {
      step.classList.toggle("active", step.dataset.stage === job.stage);
      step.classList.toggle(
        "complete",
        job.stage === "complete" || (
          ["preparing", "training", "calibrating", "evaluating"].indexOf(job.stage) >
          ["preparing", "training", "calibrating", "evaluating"].indexOf(step.dataset.stage)
        ),
      );
    });
  };

  const pollStatus = async () => {
    try {
      const response = await fetch("/api/training-status");
      const job = await response.json();
      if (!response.ok) throw new Error(job.error || "Unable to read training status.");
      updateJob(job);
      if (!job.running) {
        window.clearInterval(pollingTimer);
        pollingTimer = null;
        updateSubmit();
        return;
      }
      if (!pollingTimer) pollingTimer = window.setInterval(pollStatus, 1500);
    } catch (error) {
      showError(error.message);
      window.clearInterval(pollingTimer);
      pollingTimer = null;
      updateSubmit();
    }
  };

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    showError("");
    submitButton.disabled = true;
    submitButton.classList.add("loading");
    submitButton.querySelector(".button-label").textContent = "Validating dataset…";
    try {
      const response = await fetch("/api/train", {
        method: "POST",
        body: new FormData(form),
        headers: { "X-CSRFToken": csrfToken },
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Could not start training.");
      updateJob({
        stage: "queued",
        message: `Starting training run ${payload.run_name}`,
        running: true,
        log: [],
      });
      pollingTimer = window.setInterval(pollStatus, 1500);
      await pollStatus();
    } catch (error) {
      showError(error.message || "Could not contact the local training service.");
      updateSubmit();
    } finally {
      submitButton.classList.remove("loading");
      submitButton.querySelector(".button-label").textContent = "Validate data and start training";
      updateSubmit();
    }
  });

  pollStatus();
})();
