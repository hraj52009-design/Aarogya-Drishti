﻿import sys
from pathlib import Path

if __package__ in (None, ''):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

"""Audit a research manifest for leakage, duplicates, and cohort metadata."""

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd
from PIL import Image, UnidentifiedImageError


def file_sha256(path):
    """Return a byte-level SHA-256 hash for one image."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as file_handle:
        for block in iter(lambda: file_handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def pixel_sha256(path):
    """Return a normalized RGB pixel hash for duplicate detection."""
    with Image.open(path) as image:
        if image.format not in {"PNG", "JPEG"}:
            raise ValueError(f"Unsupported image format: {path}")
        image.load()
        rgb = image.convert("RGB")
        return hashlib.sha256(
            str(rgb.size).encode("ascii") + rgb.tobytes()
        ).hexdigest()


def audit_manifest(manifest_path):
    """Return a JSON-serializable audit report without modifying the manifest."""
    source = Path(manifest_path).resolve()
    frame = pd.read_csv(source, dtype={"patient_id": str, "group_id": str})
    required = {"path", "label"}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Manifest is missing required columns: {missing}")
    if frame[list(required)].isna().any().any():
        raise ValueError("Manifest contains missing path or label values.")
    frame["path"] = frame["path"].map(
        lambda value: str((source.parent / str(value)).resolve())
    )

    image_hashes = {}
    pixel_hashes = {}
    unreadable = []
    for image_path in frame["path"]:
        try:
            byte_hash = file_sha256(image_path)
            pixel_hash = pixel_sha256(image_path)
        except (FileNotFoundError, OSError, UnidentifiedImageError, ValueError) as exc:
            unreadable.append({"path": image_path, "error": str(exc)})
            continue
        image_hashes.setdefault(byte_hash, []).append(image_path)
        pixel_hashes.setdefault(pixel_hash, []).append(image_path)

    group_column = "patient_id" if "patient_id" in frame.columns else "group_id"
    split_overlap = {}
    if "split" in frame.columns and group_column in frame.columns:
        overlap = (
            frame.groupby(group_column)["split"].nunique()
            .loc[lambda values: values > 1]
        )
        split_overlap = {str(key): int(value) for key, value in overlap.items()}

    report = {
        "schema_version": 1,
        "manifest_path": str(source),
        "row_count": int(len(frame)),
        "columns": list(frame.columns),
        "split_counts": (
            {str(key): int(value) for key, value in frame["split"].value_counts().items()}
            if "split" in frame.columns
            else {}
        ),
        "label_counts": {
            str(key): int(value) for key, value in frame["label"].value_counts().items()
        },
        "group_column_used": group_column,
        "group_count": int(frame[group_column].nunique()) if group_column in frame else None,
        "patient_id_present": "patient_id" in frame.columns,
        "group_equals_patient_id": (
            bool(frame["group_id"].astype(str).equals(frame["patient_id"].astype(str)))
            if {"group_id", "patient_id"}.issubset(frame.columns)
            else False
        ),
        "split_group_overlap": split_overlap,
        "byte_duplicate_groups": [
            paths for paths in image_hashes.values() if len(paths) > 1
        ],
        "pixel_duplicate_groups": [
            paths for paths in pixel_hashes.values() if len(paths) > 1
        ],
        "unreadable_images": unreadable,
        "clinical_readiness_flags": [
            "Patient-independent validation is not established."
            if "patient_id" not in frame.columns
            else "Patient IDs are pseudonymous only and require provenance review.",
            "External validation must use a separate site and patient cohort.",
        ],
    }
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    report = audit_manifest(args.manifest)
    output = Path(args.out)
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite existing audit: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()


