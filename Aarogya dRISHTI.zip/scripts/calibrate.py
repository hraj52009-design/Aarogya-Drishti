﻿import sys
from pathlib import Path

if __package__ in (None, ''):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

"""Calibrate research-model confidence and review thresholds."""

import argparse
import json
from pathlib import Path
import numpy as np
import torch
from backend.core import fingerprint, load_run, read_manifest, sha256_file
from backend.selective import collect, probability_and_score

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--coverage", type=float, default=.9)
    parser.add_argument("--alpha", type=float, default=.5)
    parser.add_argument("--single-view", action="store_true")
    parser.add_argument("--no-temperature", action="store_true")
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args()
    if not 0 < args.coverage <= 1 or not 0 <= args.alpha <= 1:
        raise ValueError('Invalid coverage or alpha')
    run = Path(args.run)
    if (run / 'calibration.json').exists():
        raise FileExistsError('Calibration exists; use a separate run copy for a preplanned ablation')
    model, ck = load_run(run, args.device)
    df = read_manifest(args.manifest)
    if fingerprint(df) != ck['data_fingerprint']:
        raise ValueError('Data changed since training')
    logits, y = collect(model, df[df.split == 'cal'], ck['config']['size'], args.device)
    if args.single_view:
        logits = logits[:, :1]
    candidates = (
        [1.0] if args.no_temperature else np.geomspace(0.1, 10.0, 81).tolist()
    )
    losses = []
    for t in candidates:
        probs, _ = probability_and_score(logits, t, args.alpha)
        losses.append(-probs[torch.arange(len(y)), y].clamp_min(1e-8).log().mean().item())
    temperature = float(candidates[int(np.argmin(losses))])
    _, scores = probability_and_score(logits, temperature, args.alpha)
    threshold = float(np.quantile(scores.numpy(), args.coverage, method='higher'))
    result = {'temperature': temperature, 'alpha': args.alpha, 'threshold': threshold,
              'suspicious_threshold': 0.35,
              'single_view': args.single_view, 'requested_calibration_coverage': args.coverage,
              'empirical_calibration_coverage': float((scores <= threshold).float().mean()),
              'n_calibration_images': len(y), 'checkpoint_sha256': sha256_file(run / 'best.pt'),
              'data_fingerprint': ck['data_fingerprint'],
              'note': 'Empirical image-level quantile; conservative 0.35 suspicious threshold is not clinically validated.'}
    (run / 'calibration.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()


