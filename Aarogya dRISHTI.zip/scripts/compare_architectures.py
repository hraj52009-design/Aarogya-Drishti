﻿import sys
from pathlib import Path

if __package__ in (None, ''):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

"""Create a reproducible architecture comparison manifest.

This command reports model sizes and verifies that each candidate can execute a
forward pass. It does not claim that parameter count or a smoke test measures
clinical performance; each candidate still needs a separately trained,
calibrated, patient-level experiment.
"""

import argparse
import json
from pathlib import Path

import torch

from backend.core import MRIModel, SUPPORTED_ARCHITECTURES


def inspect_architecture(architecture, image_size=64, pretrained=False):
    """Return lightweight build and forward-pass facts for one architecture."""
    model = MRIModel(architecture, pretrained=pretrained).eval()
    sample = torch.zeros(1, 3, image_size, image_size)
    with torch.no_grad():
        output = model(sample)
    parameters = list(model.parameters())
    return {
        "architecture": architecture,
        "pretrained_requested": pretrained,
        "parameter_count": int(sum(parameter.numel() for parameter in parameters)),
        "trainable_parameter_count": int(
            sum(parameter.numel() for parameter in parameters if parameter.requires_grad)
        ),
        "input_shape": list(sample.shape),
        "output_shape": list(output.shape),
        "forward_pass_ok": list(output.shape) == [1, 2],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True)
    parser.add_argument("--size", type=int, default=64)
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args()
    if args.size < 32:
        raise ValueError("Image size must be at least 32.")
    report = {
        "schema_version": 1,
        "device": args.device,
        "comparison_type": "architecture smoke comparison; not clinical validation",
        "candidates": [
            inspect_architecture(architecture, args.size)
            for architecture in SUPPORTED_ARCHITECTURES
        ],
    }
    output = Path(args.out)
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite existing comparison: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()


