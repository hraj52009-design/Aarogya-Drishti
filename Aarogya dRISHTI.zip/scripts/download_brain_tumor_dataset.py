﻿import sys
from pathlib import Path

if __package__ in (None, ''):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

"""Download and prepare the optional public image-level benchmark."""

import argparse
import csv
import hashlib
from io import BytesIO
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request

import pyarrow.parquet as parquet
from PIL import Image, UnidentifiedImageError
from sklearn.model_selection import train_test_split

from backend.core import sha256_file

DATASET_ID = "Dharamanand/BrainTumorMRI"
DATASET_REVISION = "247d8e19a2b0c3337c0e16d00efeb7094a3ebe57"
DATASET_PAGE = f"https://huggingface.co/datasets/{DATASET_ID}"
DATASET_LICENSE = "CC0-1.0 (as declared in the Hugging Face dataset card)"
PARQUET_FILES = {
    "train-00000-of-00001.parquet": (
        "ec347ab2cb6e08e1d6192d23f0f31a0f0638268f89a097d52cacaa710c283ed2",
        "train",
    ),
    "test-00000-of-00001.parquet": (
        "32fccda876834d994acf79401f752e06389aedb1375d4ad5d42fa713b4319406",
        "test",
    ),
}
CLASS_NAMES = {0: "glioma", 1: "meningioma", 2: "no_tumor", 3: "pituitary"}
MAX_DOWNLOAD_BYTES = 512 * 1024 * 1024


def _download_file(file_name, destination):
    expected_hash, _ = PARQUET_FILES[file_name]
    if destination.exists():
        if sha256_file(destination) == expected_hash:
            return
        raise ValueError(f"Existing dataset file checksum does not match: {destination}")

    url = (
        f"https://huggingface.co/datasets/{DATASET_ID}/resolve/"
        f"{DATASET_REVISION}/data/{file_name}"
    )
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "AarogyaDrishti-local-research"},
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        prefix="dataset-", suffix=".part", dir=destination.parent, delete=False
    ) as temporary:
        temporary_path = Path(temporary.name)
    downloaded = 0
    try:
        with urllib.request.urlopen(request, timeout=60) as response, temporary_path.open(
            "wb"
        ) as output:
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                downloaded += len(block)
                if downloaded > MAX_DOWNLOAD_BYTES:
                    raise ValueError("Dataset file exceeds the configured download size limit.")
                output.write(block)
        if downloaded == 0:
            raise ValueError("Dataset server returned an empty file.")
        if sha256_file(temporary_path) != expected_hash:
            raise ValueError(f"SHA-256 verification failed for {file_name}.")
        temporary_path.replace(destination)
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"Dataset download failed with HTTP {exc.code}.") from exc
    finally:
        temporary_path.unlink(missing_ok=True)


def _records(parquet_path, source_split, expected_count):
    table = parquet.read_table(parquet_path)
    if table.column_names != ["image", "label"]:
        raise ValueError(f"Unexpected columns in public dataset file: {table.column_names}")
    if expected_count is not None and table.num_rows != expected_count:
        raise ValueError(
            f"Unexpected {source_split} row count: expected {expected_count}, got {table.num_rows}."
        )
    images = table.column("image").to_pylist()
    labels = table.column("label").to_pylist()
    rows = []
    for image, raw_label in zip(images, labels, strict=True):
        if not isinstance(image, dict) or not image.get("bytes"):
            raise ValueError("Dataset contains an image record without embedded image bytes.")
        label = int(raw_label)
        if label not in CLASS_NAMES:
            raise ValueError(f"Dataset contains unknown class ID: {label}")
        rows.append((image["bytes"], label, image.get("path") or ""))
    return rows


def _deduplicate_records(records, seen, duplicate_counts, partition):
    unique_records = []
    for image_bytes, source_label, source_path in records:
        byte_hash = hashlib.sha256(image_bytes).hexdigest()
        try:
            with Image.open(BytesIO(image_bytes)) as image:
                if image.format not in {"JPEG", "PNG"}:
                    raise ValueError("Source dataset contains an unsupported image encoding.")
                image.load()
                rgb = image.convert("RGB")
                pixel_hash = hashlib.sha256(
                    f"{rgb.width}x{rgb.height}".encode("ascii") + rgb.tobytes()
                ).hexdigest()
        except (UnidentifiedImageError, OSError) as exc:
            raise ValueError("Source dataset contains an unreadable image.") from exc

        prior_label = seen["labels"].get(pixel_hash)
        if prior_label is not None and prior_label != source_label:
            raise ValueError("Duplicate image content has conflicting labels; refusing to train.")
        if pixel_hash in seen["pixels"] or byte_hash in seen["bytes"]:
            if partition == "test":
                duplicate_counts["duplicate_test_rows_removed"] += 1
            elif pixel_hash in seen["test_pixels"]:
                duplicate_counts["training_rows_overlapping_test_removed"] += 1
            else:
                duplicate_counts["duplicate_training_rows_removed"] += 1
            continue

        seen["bytes"].add(byte_hash)
        seen["pixels"].add(pixel_hash)
        seen["labels"][pixel_hash] = source_label
        if partition == "test":
            seen["test_pixels"].add(pixel_hash)
        unique_records.append((image_bytes, source_label, source_path))
    return unique_records


def _write_partition(records, source_partition, assigned_split, image_directory):
    rows = []
    for index, (image_bytes, source_label, _) in enumerate(records):
        byte_hash = hashlib.sha256(image_bytes).hexdigest()
        try:
            with Image.open(BytesIO(image_bytes)) as image:
                if image.format not in {"JPEG", "PNG"}:
                    raise ValueError("Source dataset contains an unsupported image encoding.")
                image.load()
                rgb = image.convert("RGB")
                pixel_hash = hashlib.sha256(
                    f"{rgb.width}x{rgb.height}".encode("ascii") + rgb.tobytes()
                ).hexdigest()
        except (UnidentifiedImageError, OSError) as exc:
            raise ValueError("Source dataset contains an unreadable image.") from exc

        label = 0 if source_label == 2 else 1
        suffix = ".png" if image.format == "PNG" else ".jpg"
        image_path = image_directory / f"{source_partition}_{index:05d}_{byte_hash[:12]}{suffix}"
        if not image_path.exists():
            image_path.write_bytes(image_bytes)
        rows.append(
            {
                "path": str(image_path.resolve()),
                "label": label,
                "group_id": f"image_{byte_hash}",
                "split": assigned_split,
                "source_class": CLASS_NAMES[source_label],
                "source_partition": source_partition,
                "split_unit": "image; patient identifiers are not provided",
            }
        )
    return rows


def create_manifest(
    train_parquet,
    test_parquet,
    output_path,
    seed=42,
    expected_train_count=5969,
    expected_test_count=1054,
):
    train_records = _records(train_parquet, "train", expected_train_count)
    test_records = _records(test_parquet, "test", expected_test_count)
    output_path = Path(output_path).resolve()
    if output_path.exists():
        raise FileExistsError(f"Refusing to overwrite existing manifest: {output_path}")
    duplicate_counts = {
        "duplicate_test_rows_removed": 0,
        "duplicate_training_rows_removed": 0,
        "training_rows_overlapping_test_removed": 0,
    }
    seen = {
        "bytes": set(),
        "pixels": set(),
        "labels": {},
        "test_pixels": set(),
    }
    test_records = _deduplicate_records(test_records, seen, duplicate_counts, "test")
    train_records = _deduplicate_records(train_records, seen, duplicate_counts, "train")
    labels = [record[1] for record in train_records]
    train_indices, held_out_indices = train_test_split(
        range(len(train_records)),
        test_size=0.2,
        stratify=labels,
        random_state=seed,
    )
    val_indices, cal_indices = train_test_split(
        held_out_indices,
        test_size=0.5,
        stratify=[labels[index] for index in held_out_indices],
        random_state=seed,
    )

    split_records = [
        ("train", "train", [train_records[index] for index in train_indices]),
        ("train", "val", [train_records[index] for index in val_indices]),
        ("train", "cal", [train_records[index] for index in cal_indices]),
        ("test", "test", test_records),
    ]
    image_directory = output_path.parent / "images"
    image_directory.mkdir(parents=True, exist_ok=True)
    rows = []
    for source_partition, split_name, records in split_records:
        rows.extend(
            _write_partition(
                records,
                source_partition,
                split_name,
                image_directory,
            )
        )

    columns = [
        "path",
        "label",
        "group_id",
        "split",
        "source_class",
        "source_partition",
        "split_unit",
    ]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)
    with output_path.with_name("dataset-attribution.json").open("w", encoding="utf-8") as output:
        json.dump(
            {
                "dataset": DATASET_ID,
                "revision": DATASET_REVISION,
                "url": DATASET_PAGE,
                "license": DATASET_LICENSE,
                "license_note": (
                    "The host dataset card declares CC0-1.0. Source provenance and upstream "
                    "rights are not sufficiently documented in the card."
                ),
                "label_mapping": {
                    "0": "no_tumor (original label 2)",
                    "1": "tumor (original labels 0 glioma, 1 meningioma, 3 pituitary)",
                },
                "test_protocol": (
                    "The source test partition is held out. Exact and pixel-identical test "
                    "duplicates are collapsed; training copies overlapping the test set are "
                    "removed. Patient identifiers are unavailable."
                ),
                "duplicate_rows_removed": duplicate_counts,
            },
            output,
            indent=2,
        )
    return rows


def _run_phase(command):
    print(f"\n$ {' '.join(map(str, command))}", flush=True)
    subprocess.run(command, cwd=Path(__file__).resolve().parent, check=True)


def main():
    parser = argparse.ArgumentParser(
        description="Download a public brain MRI image dataset and train/evaluate an image-level baseline."
    )
    parser.add_argument("--run", default="public-brain-tumor-cc0")
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--size", type=int, default=64)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    if not 1 <= args.epochs <= 100 or args.size < 32:
        raise ValueError("Epochs must be 1-100 and image size must be at least 32.")
    if not args.run or len(args.run) > 40 or any(
        char not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-"
        for char in args.run
    ):
        raise ValueError("Run name must contain at most 40 letters, numbers, dashes, or underscores.")

    project_dir = Path(__file__).resolve().parent
    data_directory = project_dir / "data" / "hf_brain_tumor_mri"
    data_directory.mkdir(parents=True, exist_ok=True)
    run_directory = project_dir / "runs" / args.run
    if run_directory.exists():
        raise FileExistsError(f"Run directory already exists; choose a new name: {run_directory}")

    for file_name in PARQUET_FILES:
        _download_file(file_name, data_directory / file_name)
    manifest_path = data_directory / "manifest.csv"
    create_manifest(
        data_directory / "train-00000-of-00001.parquet",
        data_directory / "test-00000-of-00001.parquet",
        manifest_path,
        args.seed,
    )

    model_directory = run_directory / "model"
    _run_phase(
        [
            sys.executable,
            str(project_dir / "train.py"),
            "--manifest",
            str(manifest_path),
            "--run",
            str(model_directory),
            "--arch",
            "cnn",
            "--epochs",
            str(args.epochs),
            "--size",
            str(args.size),
            "--seed",
            str(args.seed),
        ]
    )
    _run_phase(
        [
            sys.executable,
            str(project_dir / "calibrate.py"),
            "--run",
            str(model_directory),
            "--manifest",
            str(manifest_path),
            "--coverage",
            "0.9",
        ]
    )
    _run_phase(
        [
            sys.executable,
            str(project_dir / "evaluate.py"),
            "--run",
            str(model_directory),
            "--manifest",
            str(manifest_path),
        ]
    )
    report_path = model_directory / "test_report.json"
    print(f"\nModel checkpoint: {model_directory / 'best.pt'}")
    print(f"Calibration: {model_directory / 'calibration.json'}")
    print(f"Held-out image-level test report: {report_path}")
    print("Dataset license/provenance and limitations: data-attribution.json")
    print("These results do not establish patient-independent or clinical performance.")


if __name__ == "__main__":
    main()


