﻿import sys
from pathlib import Path

if __package__ in (None, ''):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import argparse
import json
from pathlib import Path
"""Evaluate a calibrated checkpoint without tuning on the test partition."""

import numpy as np
import pandas as pd
from backend.core import read_manifest, fingerprint, load_run
from backend.selective import (
    collect,
    load_calibration,
    probability_and_score,
    uncertainty_summary,
)
from backend.metrics import calibration_curve, metrics, cluster_bootstrap, prevalence_metrics, threshold_metrics

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--run', required=True)
    p.add_argument('--manifest', required=True)
    p.add_argument('--device', default='cpu')
    p.add_argument('--bootstrap', type=int, default=500)
    a = p.parse_args()
    run = Path(a.run)
    if (run / 'test_report.json').exists():
        raise FileExistsError('Test report exists; do not retune on test results')
    if a.bootstrap < 1:
        raise ValueError('Bootstrap repeats must be positive')
    cal = load_calibration(run)
    model, ck = load_run(run, a.device)
    df = read_manifest(a.manifest)
    if fingerprint(df) != ck['data_fingerprint']:
        raise ValueError('Data changed since training')
    test = df[df.split == 'test'].reset_index(drop=True)
    logits, labels = collect(model, test, ck['config']['size'], a.device)
    if cal['single_view']:
        logits = logits[:, :1]
    probs, score = probability_and_score(logits, cal['temperature'], cal['alpha'])
    y, prob, score = labels.numpy(), probs[:,1].numpy(), score.numpy()
    keep = score <= cal['threshold']
    report = {'full_cohort': metrics(y,prob), 'retained_subset': metrics(y[keep],prob[keep]),
              'coverage': float(keep.mean()), 'review_count': int((~keep).sum()),
              'coverage_by_true_class': {str(c): float(keep[y == c].mean()) for c in [0,1]},
              'bootstrap_full_cohort': cluster_bootstrap(y,prob,test.group_id.to_numpy(),a.bootstrap),
              'decision_threshold': .5,
              'operating_points': {
                  str(threshold): threshold_metrics(y, prob, threshold)
                  for threshold in (.2, .35, .5, .7)
              },
              'prevalence_aware_ppv_npv_at_decision_threshold': prevalence_metrics(y, prob, .5),
              'calibration': {
                  'reliability_bins': calibration_curve(y, prob),
                  'brier': metrics(y, prob)['brier'],
                  'ece_15_bins': metrics(y, prob)['ece_15_bins'],
              },
              'uncertainty': uncertainty_summary(
                  logits,
                  cal['temperature'],
                  cal['threshold'],
                  cal['alpha'],
              ),
              'warning': 'Retained-subset metrics do not replace full-cohort metrics. Review flags are not diagnoses.'}
    (run / 'test_report.json').write_text(json.dumps(report,indent=2,allow_nan=False))
    # No patient IDs or image paths exported here; treat even scores as sensitive.
    pd.DataFrame({'label': y, 'tumor_probability': prob, 'review_score': score,
                  'retained': keep}).to_csv(run / 'test_predictions.csv',index=False)
    curve = []
    for threshold in np.unique(np.r_[0.,np.linspace(0,1,101),cal['threshold'],1.]):
        retained = score <= threshold
        risk = float(((prob[retained] >= .5) != y[retained]).mean()) if retained.any() else None
        curve.append({'threshold': float(threshold), 'coverage': float(retained.mean()), 'error_rate': risk})
    pd.DataFrame(curve).to_csv(run / 'risk_coverage.csv',index=False)
    print(json.dumps(report,indent=2))
    print('Threshold-sweep curve is descriptive only; do not use test data to select a threshold.')

if __name__ == '__main__':
    main()


