﻿import sys
from pathlib import Path

if __package__ in (None, ''):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

"""Run frozen-checkpoint validation on an independent image manifest."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import pandas as pd
from PIL import Image, UnidentifiedImageError

from backend.core import sha256_file, fingerprint, load_run, read_manifest
from backend.metrics import calibration_curve, cluster_bootstrap, metrics, prevalence_metrics, threshold_metrics
from backend.selective import (
    collect,
    load_calibration,
    probability_and_score,
    uncertainty_summary,
)


def _pixel_digest(path):
    with Image.open(path) as image:
        if image.format not in {"PNG", "JPEG"}:
            raise ValueError(f"Unsupported external image format: {path}")
        if min(image.size) < 32:
            raise ValueError(f"External image dimensions must be at least 32 x 32: {path}")
        if image.width * image.height > 16_000_000:
            raise ValueError(f"External image exceeds the 16-megapixel limit: {path}")
        image.load()
        rgb = image.convert("RGB")
        return hashlib.sha256(
            str(rgb.size).encode("ascii") + rgb.tobytes()
        ).hexdigest()


def load_external_manifest(path):
    manifest_path = Path(path).resolve()
    frame = pd.read_csv(manifest_path, dtype={"patient_id": str, "site_id": str})
    required = {"path", "label", "patient_id", "site_id"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"External manifest requires columns: {sorted(required)}")
    if frame[list(required)].isna().any().any():
        raise ValueError("External manifest contains missing required values.")

    for column in ("patient_id", "site_id"):
        frame[column] = frame[column].astype(str).str.strip()
        if (frame[column] == "").any():
            raise ValueError(f"External manifest contains an empty {column}.")

    if not frame["label"].isin([0, 1]).all():
        raise ValueError("External labels must be binary integers 0 or 1.")
    frame["label"] = frame["label"].astype(int)
    if set(frame["label"]) != {0, 1}:
        raise ValueError("External cohort must contain both reference-label classes.")

    frame["path"] = frame["path"].map(
        lambda value: str((manifest_path.parent / str(value)).resolve())
    )
    if frame["path"].duplicated().any():
        raise ValueError("External manifest contains repeated image paths.")
    if (frame.groupby("patient_id")["site_id"].nunique() > 1).any():
        raise ValueError("Each external patient must map to one pseudonymous site_id.")

    pixel_hashes = set()
    byte_hashes = set()
    for image_path in frame["path"]:
        path_obj = Path(image_path)
        if not path_obj.is_file():
            raise FileNotFoundError(f"External image does not exist: {image_path}")
        try:
            raw_hash = sha256_file(path_obj)
            pixel_hash = _pixel_digest(path_obj)
        except (UnidentifiedImageError, OSError) as exc:
            raise ValueError(f"Unreadable external image: {image_path}") from exc
        if raw_hash in byte_hashes or pixel_hash in pixel_hashes:
            raise ValueError("Exact or pixel-identical duplicate in external cohort.")
        byte_hashes.add(raw_hash)
        pixel_hashes.add(pixel_hash)

    frame["group_id"] = frame["patient_id"]
    return frame


def audit_external_against_training(external, training):
    if "patient_id" not in training.columns or not training["group_id"].equals(
        training["patient_id"].astype(str)
    ):
        raise ValueError(
            "Clinical-validation groundwork requires training data grouped by true "
            "pseudonymous patient_id; image-level group_id runs are not eligible."
        )

    overlap = set(external["patient_id"]) & set(training["patient_id"].astype(str))
    if overlap:
        raise ValueError("External cohort contains patient IDs present in training data.")

    training_byte_hashes = set()
    training_pixel_hashes = set()
    for image_path in training["path"]:
        path_obj = Path(image_path)
        if not path_obj.is_file():
            raise FileNotFoundError(f"Training image does not exist: {image_path}")
        training_byte_hashes.add(sha256_file(path_obj))
        try:
            training_pixel_hashes.add(_pixel_digest(path_obj))
        except (UnidentifiedImageError, OSError) as exc:
            raise ValueError(f"Unreadable training image: {image_path}") from exc

    for image_path in external["path"]:
        if sha256_file(image_path) in training_byte_hashes:
            raise ValueError("External cohort contains an image byte-identical to training data.")
        if _pixel_digest(image_path) in training_pixel_hashes:
            raise ValueError("External cohort contains a pixel-identical training image.")


def external_cohort_preflight(external):
    """Return readiness facts before running a frozen-checkpoint evaluation."""
    patient_labels = external.groupby("patient_id")["label"].first()
    site_patient_counts = (
        external.groupby("site_id")["patient_id"].nunique().sort_index()
    )
    return {
        "patient_count": int(external["patient_id"].nunique()),
        "site_count": int(external["site_id"].nunique()),
        "image_count": int(len(external)),
        "class_patient_counts": {
            str(label): int(count)
            for label, count in patient_labels.value_counts().sort_index().items()
        },
        "patients_per_site": {
            str(site): int(count) for site, count in site_patient_counts.items()
        },
        "has_both_classes_per_site": bool(
            external.groupby("site_id")["label"].nunique().ge(2).all()
        ),
        "has_multiple_sites": bool(external["site_id"].nunique() >= 2),
        "evaluation_gate": (
            "ready_for_external_research_evaluation"
            if external["site_id"].nunique() >= 2
            else "single_site_external_cohort_requires_caution"
        ),
        "warning": (
            "This preflight is a data-structure check, not evidence of clinical "
            "validity or diagnostic performance."
        ),
    }


def build_external_report(labels, probabilities, review_scores, patients, sites, calibration, bootstrap):
    retained = review_scores <= calibration["threshold"]
    report = {
        "evaluation_type": "external patient-grouped image-level validation",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "n_images": int(len(labels)),
        "n_patients": int(pd.Series(patients).nunique()),
        "n_sites": int(pd.Series(sites).nunique()),
        "cohort_preflight": external_cohort_preflight(
            pd.DataFrame(
                {
                    "patient_id": patients,
                    "site_id": sites,
                    "label": labels,
                }
            )
        ),
        "class_counts": {
            str(label): int((labels == label).sum()) for label in (0, 1)
        },
        "full_cohort": metrics(labels, probabilities),
        "retained_subset": metrics(labels[retained], probabilities[retained]),
        "review_threshold_from_locked_calibration": float(calibration["threshold"]),
        "coverage": float(retained.mean()),
        "review_count": int((~retained).sum()),
        "coverage_by_true_class": {
            str(label): float(retained[labels == label].mean()) for label in (0, 1)
        },
        "bootstrap_patient_cluster": cluster_bootstrap(
            labels, probabilities, patients, repeats=bootstrap
        ),
        "site_strata": {},
        "decision_threshold": 0.5,
        "operating_points": {
            str(threshold): threshold_metrics(labels, probabilities, threshold)
            for threshold in (0.20, 0.35, 0.50, 0.70)
        },
        "prevalence_aware_ppv_npv_at_decision_threshold": prevalence_metrics(
            labels, probabilities, 0.5
        ),
        "calibration": {
            "brier": metrics(labels, probabilities)["brier"],
            "ece_15_bins": metrics(labels, probabilities)["ece_15_bins"],
            "reliability_bins": calibration_curve(labels, probabilities),
        },
        "uncertainty": {
            "review_threshold": float(calibration["threshold"]),
            "mean_review_score": float(review_scores.mean()),
            "review_count": int((~retained).sum()),
            "retained_fraction": float(retained.mean()),
            "note": (
                "External uncertainty values are descriptive and do not establish "
                "clinical confidence or safety."
            ),
        },
        "warning": (
            "External image-level results are not clinical validation, do not establish "
            "patient-level diagnostic performance, and must not guide care."
        ),
    }
    for site in sorted(pd.Series(sites).unique()):
        site_mask = sites == site
        report["site_strata"][str(site)] = {
            "n_images": int(site_mask.sum()),
            "n_patients": int(pd.Series(patients[site_mask]).nunique()),
            "class_counts": {
                str(label): int((labels[site_mask] == label).sum()) for label in (0, 1)
            },
            "metrics": metrics(labels[site_mask], probabilities[site_mask]),
        }
    return report


def run_external_validation(run, training_manifest, external_manifest, output, device="cpu", bootstrap=500):
    if bootstrap < 1:
        raise ValueError("Bootstrap repeats must be positive.")
    run_path = Path(run).resolve()
    output_path = Path(output).resolve()
    if output_path.exists():
        raise FileExistsError("Choose a new output directory; existing reports are not overwritten.")

    calibration = load_calibration(run_path)
    model, checkpoint = load_run(run_path, device)
    training = read_manifest(training_manifest)
    if fingerprint(training) != checkpoint["data_fingerprint"]:
        raise ValueError("Training data fingerprint does not match the model checkpoint.")
    external = load_external_manifest(external_manifest)
    audit_external_against_training(external, training)

    logits, labels = collect(
        model, external, checkpoint["config"]["size"], device
    )
    if calibration["single_view"]:
        logits = logits[:, :1]
    probabilities, scores = probability_and_score(
        logits, calibration["temperature"], calibration["alpha"]
    )
    labels_np = labels.numpy()
    tumor_probabilities = probabilities[:, 1].numpy()
    scores_np = scores.numpy()
    patients = external["patient_id"].to_numpy()
    sites = external["site_id"].to_numpy()
    report = build_external_report(
        labels_np, tumor_probabilities, scores_np, patients, sites, calibration, bootstrap
    )
    report["checkpoint_sha256"] = sha256_file(run_path / "best.pt")
    report["training_data_fingerprint"] = checkpoint["data_fingerprint"]
    report["external_manifest_sha256"] = sha256_file(external_manifest)
    output_path.mkdir(parents=True, exist_ok=False)
    (output_path / "external_validation.json").write_text(
        json.dumps(report, indent=2, allow_nan=False), encoding="utf-8"
    )
    return report


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Evaluate a frozen research checkpoint on an independently collected, "
            "patient-grouped external image cohort. This does not establish clinical readiness."
        )
    )
    parser.add_argument("--run", required=True)
    parser.add_argument("--training-manifest", required=True)
    parser.add_argument("--external-manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--bootstrap", type=int, default=500)
    args = parser.parse_args()

    report = run_external_validation(
        args.run,
        args.training_manifest,
        args.external_manifest,
        args.output,
        args.device,
        args.bootstrap,
    )
    print(json.dumps(report, indent=2, allow_nan=False))
    print("Do not use these image-level research results to guide patient care.")


if __name__ == "__main__":
    main()


