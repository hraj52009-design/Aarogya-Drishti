﻿import sys
from pathlib import Path

if __package__ in (None, ''):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

"""Freeze a reproducible, read-only snapshot of an existing model run."""

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def file_sha256(path):
    """Return the SHA-256 hash for a file without loading it all at once."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as file_handle:
        for block in iter(lambda: file_handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path):
    """Load a JSON artifact and fail clearly when it is missing or invalid."""
    artifact_path = Path(path)
    if not artifact_path.is_file():
        raise FileNotFoundError(f"Required baseline artifact is missing: {artifact_path}")
    return json.loads(artifact_path.read_text(encoding="utf-8"))


def freeze_run(run_directory, output_path):
    """Write an immutable metadata snapshot for a completed research run."""
    run_path = Path(run_directory).resolve()
    output = Path(output_path).resolve()
    required_files = {
        name: run_path / name
        for name in (
            "best.pt",
            "config.json",
            "provenance.json",
            "calibration.json",
            "test_report.json",
        )
    }
    missing = [str(path) for path in required_files.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"Cannot freeze incomplete run; missing: {missing}")
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite an existing freeze: {output}")

    config = load_json(required_files["config.json"])
    provenance = load_json(required_files["provenance.json"])
    calibration = load_json(required_files["calibration.json"])
    test_report = load_json(required_files["test_report.json"])
    manifest_path = Path(config["manifest"]).resolve()

    snapshot = {
        "schema_version": 1,
        "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
        "run_directory": str(run_path),
        "manifest_path": str(manifest_path),
        "intended_use": "research-only image-level triage; not diagnosis",
        "known_limitations": [
            "The source manifest has no patient_id column.",
            "The current group_id values are image-level identifiers, not verified patients.",
            "The benchmark does not establish patient-independent or clinical performance.",
            "All outputs require qualified radiologist review.",
        ],
        "config": config,
        "provenance": provenance,
        "calibration": calibration,
        "test_report": test_report,
        "artifact_sha256": {
            name: file_sha256(path) for name, path in required_files.items()
        },
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(snapshot, indent=2, sort_keys=True), encoding="utf-8")
    return snapshot


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True, help="Completed model directory")
    parser.add_argument("--out", required=True, help="New JSON freeze path")
    args = parser.parse_args()
    snapshot = freeze_run(args.run, args.out)
    print(json.dumps({
        "frozen_run": snapshot["run_directory"],
        "output": str(Path(args.out).resolve()),
        "artifact_count": len(snapshot["artifact_sha256"]),
    }, indent=2))


if __name__ == "__main__":
    main()


