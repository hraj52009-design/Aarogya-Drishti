﻿import sys
from pathlib import Path

if __package__ in (None, ''):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

"""Validate and split patient-level MRI manifests for research experiments."""

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd


REQUIRED_COLUMNS = {"path", "label", "patient_id", "site_id"}
OPTIONAL_COLUMNS = {"study_id", "sequence", "modality", "source_dataset"}
VALID_LABELS = {0, 1}
VALID_SPLITS = {"train", "val", "cal", "test", "external"}


def _normalise_identifier(frame, column):
    values = frame[column].astype(str).str.strip()
    if (values == "").any():
        raise ValueError(f"Manifest contains an empty {column}.")
    frame[column] = values


def _sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as file_handle:
        for block in iter(lambda: file_handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_patient_manifest(path, require_existing_files=True):
    """Load a patient-level manifest and reject unsafe split definitions."""
    manifest_path = Path(path).resolve()
    frame = pd.read_csv(
        manifest_path,
        dtype={"patient_id": str, "study_id": str, "site_id": str},
    )
    missing = sorted(REQUIRED_COLUMNS - set(frame.columns))
    if missing:
        raise ValueError(f"Patient manifest requires columns: {missing}")
    if frame.empty:
        raise ValueError("Patient manifest must contain at least one row.")
    if frame[list(REQUIRED_COLUMNS)].isna().any().any():
        raise ValueError("Patient manifest contains missing required values.")

    for column in ("patient_id", "site_id"):
        _normalise_identifier(frame, column)
    if "study_id" in frame:
        _normalise_identifier(frame, "study_id")
    if not frame["label"].isin(VALID_LABELS).all():
        raise ValueError("Patient labels must be binary integers: 0 or 1.")
    frame["label"] = frame["label"].astype(int)
    frame["path"] = frame["path"].map(
        lambda value: str((manifest_path.parent / str(value)).resolve())
    )
    if frame["path"].duplicated().any():
        raise ValueError("Patient manifest contains repeated image/volume paths.")

    if "study_id" not in frame:
        frame["study_id"] = frame["patient_id"] + "::study-1"
    if (frame.groupby("study_id")["patient_id"].nunique() > 1).any():
        raise ValueError("Each study_id must belong to exactly one patient_id.")
    if (frame.groupby("patient_id")["site_id"].nunique() > 1).any():
        raise ValueError("Each patient_id must map to one site_id.")
    if (frame.groupby("patient_id")["label"].nunique() > 1).any():
        raise ValueError("All rows for a patient must have the same label.")

    if "split" in frame:
        invalid_splits = set(frame["split"].dropna()) - VALID_SPLITS
        if invalid_splits:
            raise ValueError(f"Unsupported split names: {sorted(invalid_splits)}")
        if frame["split"].isna().any():
            raise ValueError("Split values cannot be missing.")
        patient_split_count = frame.groupby("patient_id")["split"].nunique()
        if (patient_split_count > 1).any():
            raise ValueError("A patient appears in more than one split.")
        study_split_count = frame.groupby("study_id")["split"].nunique()
        if (study_split_count > 1).any():
            raise ValueError("A study appears in more than one split.")

    if require_existing_files:
        missing_files = [
            image_path for image_path in frame["path"] if not Path(image_path).is_file()
        ]
        if missing_files:
            raise FileNotFoundError(
                f"Manifest references {len(missing_files)} missing files; "
                f"first: {missing_files[0]}"
            )
    return frame


def create_patient_splits(frame, seed=42, test_fraction=0.15, calibration_fraction=0.10):
    """Create patient-level train/validation/calibration/test assignments."""
    from sklearn.model_selection import train_test_split

    patients = frame[["patient_id", "site_id", "label"]].drop_duplicates()
    if patients["label"].value_counts().min() < 4:
        raise ValueError("At least four independent patients per class are required.")

    remaining, test = train_test_split(
        patients,
        test_size=test_fraction,
        stratify=patients["label"],
        random_state=seed,
    )
    remaining, calibration = train_test_split(
        remaining,
        test_size=calibration_fraction / (1 - test_fraction),
        stratify=remaining["label"],
        random_state=seed,
    )
    train, validation = train_test_split(
        remaining,
        test_size=0.15 / 0.75,
        stratify=remaining["label"],
        random_state=seed,
    )
    assignments = {}
    for split_name, cohort in (
        ("train", train),
        ("val", validation),
        ("cal", calibration),
        ("test", test),
    ):
        assignments.update(dict.fromkeys(cohort["patient_id"], split_name))
    result = frame.copy()
    result["split"] = result["patient_id"].map(assignments)
    if result["split"].isna().any():
        raise ValueError("Could not assign every patient to a split.")
    return result


def build_pipeline_report(frame):
    """Summarise cohort structure without exporting patient identifiers."""
    return {
        "schema_version": 1,
        "row_count": int(len(frame)),
        "patient_count": int(frame["patient_id"].nunique()),
        "study_count": int(frame["study_id"].nunique()),
        "site_count": int(frame["site_id"].nunique()),
        "label_counts": {
            str(label): int(count)
            for label, count in frame.groupby("patient_id")["label"]
            .first()
            .value_counts()
            .items()
        },
        "rows_by_split": (
            {str(split): int(count) for split, count in frame["split"].value_counts().items()}
            if "split" in frame
            else {}
        ),
        "patients_by_split": (
            {
                str(split): int(count)
                for split, count in frame.groupby("split")["patient_id"].nunique().items()
            }
            if "split" in frame
            else {}
        ),
        "site_by_split": (
            {
                str(split): sorted(frame.loc[frame["split"] == split, "site_id"].unique())
                for split in frame["split"].unique()
            }
            if "split" in frame
            else {}
        ),
        "warning": (
            "This contract supports research data preparation only. "
            "It does not establish clinical validity."
        ),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--report", required=True)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    source = validate_patient_manifest(args.manifest)
    split_frame = create_patient_splits(source, seed=args.seed)
    output = Path(args.out)
    report_path = Path(args.report)
    if output.exists() or report_path.exists():
        raise FileExistsError("Refusing to overwrite existing pipeline outputs.")
    output.parent.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    split_frame.to_csv(output, index=False)
    report_path.write_text(
        json.dumps(build_pipeline_report(split_frame), indent=2, sort_keys=True),
        encoding="utf-8",
    )
    print(json.dumps(build_pipeline_report(split_frame), indent=2))


if __name__ == "__main__":
    main()


