﻿import sys
from pathlib import Path

if __package__ in (None, ''):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

"""Validate an image manifest and create group-aware dataset splits."""

import argparse
import hashlib
from pathlib import Path
from PIL import Image
from sklearn.model_selection import train_test_split

from backend.core import read_manifest, sha256_file

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    df = read_manifest(args.manifest, require_split=False)
    seen_bytes, seen_pixels = set(), set()
    for row in df.itertuples():
        raw = sha256_file(row.path)
        with Image.open(row.path) as img:
            if img.format not in ('JPEG', 'PNG'):
                raise ValueError('Only approved 2D PNG/JPEG inputs supported')
            img.load()
            if min(img.size) < 32:
                raise ValueError(f'Too small: {row.path}')
            rgb = img.convert('RGB')
            pixel = hashlib.sha256(str(rgb.size).encode() + rgb.tobytes()).hexdigest()
        if raw in seen_bytes or pixel in seen_pixels:
            raise ValueError('Duplicate content detected; resolve before splitting')
        seen_bytes.add(raw)
        seen_pixels.add(pixel)
    groups = df[['group_id', 'label']].drop_duplicates()
    def split(table, fraction):
        return train_test_split(
            table,
            test_size=fraction,
            stratify=table.label,
            random_state=args.seed,
        )
    remaining, test = split(groups, .15)
    remaining, cal = split(remaining, .10 / .85)
    train, val = split(remaining, .15 / .75)
    mapping = {}
    for name, table in [('train', train), ('val', val), ('cal', cal), ('test', test)]:
        if set(table.label) != {0, 1}:
            raise ValueError('Not enough independent groups per class for four splits')
        mapping.update(dict.fromkeys(table.group_id, name))
    df['split'] = df.group_id.map(mapping)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        raise FileExistsError('Choose a new output; existing split will not be overwritten')
    df.to_csv(out, index=False)
    summary = df.groupby(['split', 'label']).agg(images=('path','size'), groups=('group_id','nunique'))
    summary.to_csv(out.with_suffix('.summary.csv'))
    print(summary)
    print('Exact duplicates checked. Near-duplicates and site/group validity still need human audit.')

if __name__ == '__main__':
    main()


