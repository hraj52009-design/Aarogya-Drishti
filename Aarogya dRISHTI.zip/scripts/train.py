﻿import sys
from pathlib import Path

if __package__ in (None, ''):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

"""Train the CNN or transfer-learning baseline used by the research app."""

import argparse
import json
import platform
from pathlib import Path
import torch
import torch.nn.functional as F
import torchvision
from torch.utils.data import DataLoader
from backend.core import (
    MRIModel,
    MRIDataset,
    SUPPORTED_ARCHITECTURES,
    fingerprint,
    read_manifest,
    seed_all,
)

def symmetric_kl(a, b):
    """Measure disagreement between two batches of model logits."""
    return .5 * (F.kl_div(F.log_softmax(a, 1), F.softmax(b, 1), reduction='batchmean') +
                 F.kl_div(F.log_softmax(b, 1), F.softmax(a, 1), reduction='batchmean'))

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--manifest', required=True)
    p.add_argument('--run', required=True)
    p.add_argument('--arch', choices=SUPPORTED_ARCHITECTURES, default='cnn')
    p.add_argument('--pretrained', action='store_true')
    p.add_argument('--consistency', type=float, default=0.)
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--patience', type=int, default=5)
    p.add_argument('--batch', type=int, default=16)
    p.add_argument('--size', type=int, default=224)
    p.add_argument('--lr', type=float, default=1e-4)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    a = p.parse_args()
    if min(a.epochs, a.patience, a.batch) < 1 or a.size < 32 or a.lr <= 0 or a.consistency < 0:
        raise ValueError('Invalid training arguments')
    if a.pretrained and a.arch not in {'resnet50', 'efficientnet_b0'}:
        raise ValueError(
            'Pretrained weights are supported only for ResNet50 and EfficientNet-B0.'
        )
    seed_all(a.seed)
    df = read_manifest(a.manifest)
    data_hash = fingerprint(df)
    run = Path(a.run)
    run.mkdir(parents=True, exist_ok=True)
    if any(run.iterdir()):
        raise FileExistsError('Run directory must be empty')
    config = vars(a)
    (run / 'config.json').write_text(json.dumps(config, indent=2))
    provenance = {'python': platform.python_version(), 'torch': str(torch.__version__),
                  'torchvision': str(torchvision.__version__), 'data_fingerprint': data_hash}
    (run / 'provenance.json').write_text(json.dumps(provenance, indent=2))
    loaders = {name: DataLoader(MRIDataset(df[df.split == name], a.size, name == 'train'),
                               batch_size=a.batch, shuffle=name == 'train', num_workers=0)
               for name in ['train', 'val']}
    model = MRIModel(a.arch, a.pretrained).to(a.device)
    counts = df[df.split == 'train'].label.value_counts().reindex([0,1]).to_numpy()
    weights = torch.tensor(counts.sum() / (2 * counts), dtype=torch.float32, device=a.device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=1e-4)
    best, stale, history = float('inf'), 0, []
    for epoch in range(a.epochs):
        record = {'epoch': epoch + 1}
        for phase, loader in loaders.items():
            training = phase == 'train'
            model.train(training)
            total, correct, n = 0., 0, 0
            for x, y in loader:
                x, y = x.to(a.device), y.to(a.device)
                with torch.set_grad_enabled(training):
                    logits = model(x)
                    # Plain validation CE for comparable model selection.
                    loss = F.cross_entropy(logits, y, weight=weights if training else None)
                    if training and a.consistency > 0:
                        gamma = .9 + .2 * torch.rand(1).item()
                        altered = model(x.clamp(0,1).pow(gamma))
                        loss = loss + a.consistency * symmetric_kl(logits, altered)
                    if training:
                        optimizer.zero_grad(set_to_none=True)
                        loss.backward()
                        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.)
                        optimizer.step()
                total += loss.item() * len(y)
                correct += (logits.argmax(1) == y).sum().item()
                n += len(y)
            record[phase + '_loss'] = total / n
            record[phase + '_accuracy'] = correct / n
        history.append(record)
        (run / 'history.json').write_text(json.dumps(history, indent=2))
        print(record)
        if record['val_loss'] < best:
            best, stale = record['val_loss'], 0
            torch.save({'state': model.state_dict(), 'config': config,
                        'data_fingerprint': data_hash, 'epoch': epoch + 1}, run / 'best.pt')
        else:
            stale += 1
            if stale >= a.patience:
                break
    print('Best checkpoint saved. Calibrate before test evaluation or inference.')

if __name__ == '__main__':
    main()


