import re
from io import BytesIO
import sys

import pytest
from PIL import Image

import app as app_module


def _png_bytes(size=(64, 64)):
    image_data = BytesIO()
    Image.new("RGB", size, color="gray").save(image_data, format="PNG")
    image_data.seek(0)
    return image_data


@pytest.fixture
def authenticated_client(tmp_path):
    application = app_module.create_app(
        {
            "TESTING": True,
            "INSTANCE_PATH": str(tmp_path / "instance"),
            "RUNS_DIR": str(tmp_path / "runs"),
            "RESEARCH_INFERENCE_ENABLED": True,
        }
    )
    client = application.test_client()
    setup_page = client.get("/setup")
    token = re.search(rb'name="csrf_token" value="([^"]+)"', setup_page.data).group(1).decode()
    client.post(
        "/setup",
        data={"csrf_token": token, "username": "researcher", "password": "test-password-123"},
    )
    return client


def _csrf_header(client):
    with client.session_transaction() as session:
        return {"X-CSRFToken": session["csrf_token"]}


def _make_model_files(client, run_name="research-run"):
    with client.application.app_context():
        from pathlib import Path

        model_dir = Path(client.application.config["RUNS_DIR"]) / run_name / "model"
        model_dir.mkdir(parents=True)
        (model_dir / "best.pt").write_bytes(b"test")
        (model_dir / "calibration.json").write_text("{}", encoding="utf-8")
        (model_dir / "test_report.json").write_text("{}", encoding="utf-8")


def test_first_visit_provides_one_time_admin_setup(tmp_path):
    application = app_module.create_app(
        {
            "TESTING": True,
            "INSTANCE_PATH": str(tmp_path / "instance"),
            "RUNS_DIR": str(tmp_path / "runs"),
        }
    )

    response = application.test_client().get("/")

    assert response.status_code == 302
    assert response.headers["Location"].endswith("/setup")


def test_home_page_serves_custom_ui(authenticated_client):
    response = authenticated_client.get("/")

    assert response.status_code == 200
    assert b"MRI image analysis" in response.data
    assert b"Run model check" in response.data
    assert b"Internal research only" in response.data
    assert b"patient-independent or clinical validation" in response.data
    assert b"Research protocol" not in response.data
    assert b"Read limitations" not in response.data


def test_research_inference_is_disabled_by_default(tmp_path):
    application = app_module.create_app(
        {
            "TESTING": True,
            "INSTANCE_PATH": str(tmp_path / "instance"),
            "RUNS_DIR": str(tmp_path / "runs"),
        }
    )
    client = application.test_client()
    setup_page = client.get("/setup")
    token = re.search(rb'name="csrf_token" value="([^"]+)"', setup_page.data).group(1).decode()
    client.post(
        "/setup",
        data={"csrf_token": token, "username": "researcher", "password": "test-password-123"},
    )

    page = client.get("/")
    models = client.get("/api/models")
    prediction = client.post(
        "/api/predict",
        data={"image": (_png_bytes(), "sample.png"), "run_name": "research-run"},
        headers=_csrf_header(client),
        content_type="multipart/form-data",
    )

    assert b"Inference is disabled by default" in page.data
    assert models.status_code == 200
    assert models.json == {
        "enabled": False,
        "models": [],
        "message": "Research inference is disabled. It is not approved for clinical use.",
    }
    assert prediction.status_code == 403
    assert "not clinically validated" in prediction.json["error"]


def test_prediction_cli_is_disabled_without_research_opt_in(monkeypatch):
    import predict

    monkeypatch.delenv("AAROGYADRISHTI_ENABLE_RESEARCH_INFERENCE", raising=False)
    monkeypatch.setattr(sys, "argv", ["predict.py", "--run", "unused", "--image", "unused.png"])

    with pytest.raises(SystemExit) as error:
        predict.main()

    assert error.value.code == 2


def test_training_page_renders_local_dataset_workflow(authenticated_client):
    response = authenticated_client.get("/training")

    assert response.status_code == 200
    assert b"Full path to manifest CSV" in response.data
    assert b"Evaluate once" in response.data


def test_protected_api_requires_sign_in(tmp_path):
    application = app_module.create_app(
        {
            "TESTING": True,
            "INSTANCE_PATH": str(tmp_path / "instance"),
            "RUNS_DIR": str(tmp_path / "runs"),
        }
    )

    response = application.test_client().get("/api/models")

    assert response.status_code == 401
    assert "administrator" in response.json["error"]


def test_post_without_csrf_token_is_rejected(authenticated_client):
    response = authenticated_client.post("/api/train", data={})

    assert response.status_code == 400
    assert "verification failed" in response.json["error"]


def test_login_and_logout(authenticated_client):
    with authenticated_client.session_transaction() as flask_session:
        flask_session.clear()
    login_page = authenticated_client.get("/login")
    token = re.search(rb'name="csrf_token" value="([^"]+)"', login_page.data).group(1).decode()

    response = authenticated_client.post(
        "/login",
        data={
            "csrf_token": token,
            "username": "researcher",
            "password": "test-password-123",
        },
    )

    assert response.status_code == 302
    assert authenticated_client.get("/").status_code == 200
    logout = authenticated_client.post("/logout", headers=_csrf_header(authenticated_client))
    assert logout.status_code == 302
    assert authenticated_client.get("/").status_code == 302


def test_login_controls_and_remember_me_behavior(authenticated_client):
    with authenticated_client.session_transaction() as flask_session:
        flask_session.clear()
    login_page = authenticated_client.get("/login")
    assert b"Remember me" in login_page.data
    assert b"Forgot password?" not in login_page.data
    assert b"data-password-toggle" in login_page.data

    token = re.search(rb'name="csrf_token" value="([^"]+)"', login_page.data).group(1).decode()
    response = authenticated_client.post(
        "/login",
        data={
            "csrf_token": token,
            "username": "researcher",
            "password": "test-password-123",
        },
    )
    assert response.status_code == 302
    with authenticated_client.session_transaction() as flask_session:
        assert flask_session.permanent is False


def test_local_signup_and_password_reset(authenticated_client):
    with authenticated_client.session_transaction() as flask_session:
        flask_session.clear()

    signup_page = authenticated_client.get("/signup")
    signup_token = re.search(rb'name="csrf_token" value="([^"]+)"', signup_page.data).group(1).decode()
    signup = authenticated_client.post(
        "/signup",
        data={
            "csrf_token": signup_token,
            "username": "second-user",
            "password": "Second-password-123",
            "password_confirm": "Second-password-123",
        },
    )
    assert signup.status_code == 302
    assert signup.headers["Location"].endswith("/login?message=Account+created.+Sign+in+to+continue.")

    reset_page = authenticated_client.get("/forgot-password")
    reset_token = re.search(rb'name="csrf_token" value="([^"]+)"', reset_page.data).group(1).decode()
    reset = authenticated_client.post(
        "/forgot-password",
        data={
            "csrf_token": reset_token,
            "username": "second-user",
            "password": "Updated-password-123",
            "password_confirm": "Updated-password-123",
        },
    )
    assert reset.status_code == 302


def test_password_reset_rejects_non_local_requests(authenticated_client):
    with authenticated_client.session_transaction() as flask_session:
        flask_session.clear()
    reset_page = authenticated_client.get("/forgot-password")
    reset_token = re.search(rb'name="csrf_token" value="([^"]+)"', reset_page.data).group(1).decode()
    response = authenticated_client.post(
        "/forgot-password",
        data={
            "csrf_token": reset_token,
            "username": "researcher",
            "password": "Updated-password-123",
            "password_confirm": "Updated-password-123",
        },
        environ_base={"REMOTE_ADDR": "203.0.113.10"},
    )
    assert response.status_code == 403


def test_signup_user_gets_user_dashboard_and_admin_area_is_restricted(authenticated_client):
    with authenticated_client.session_transaction() as flask_session:
        flask_session.clear()
    signup_page = authenticated_client.get("/signup")
    token = re.search(rb'name="csrf_token" value="([^"]+)"', signup_page.data).group(1).decode()
    signup = authenticated_client.post(
        "/signup",
        data={
            "csrf_token": token,
            "username": "standard-user",
            "password": "Standard-user-123",
            "password_confirm": "Standard-user-123",
        },
    )
    assert signup.status_code == 302

    login_page = authenticated_client.get("/login")
    login_token = re.search(rb'name="csrf_token" value="([^"]+)"', login_page.data).group(1).decode()
    login = authenticated_client.post(
        "/login",
        data={
            "csrf_token": login_token,
            "username": "standard-user",
            "password": "Standard-user-123",
        },
    )
    assert login.status_code == 302
    assert login.headers["Location"].endswith("/user-dashboard")
    assert authenticated_client.get("/training").status_code == 302
    assert authenticated_client.get("/admin-dashboard").status_code == 302
    assert authenticated_client.get("/admin/users").status_code == 302
    assert authenticated_client.get("/review-queue").status_code == 404
    assert authenticated_client.get("/api/review-queue").status_code == 200


def test_production_requires_secure_session_cookie(tmp_path):
    with pytest.raises(RuntimeError, match="secure HTTPS session cookies"):
        app_module.create_app(
            {
                "TESTING": True,
                "APP_ENV": "production",
                "SESSION_COOKIE_SECURE": False,
                "INSTANCE_PATH": str(tmp_path / "instance"),
            }
        )


def test_signup_rejects_mismatched_or_weak_passwords(authenticated_client):
    with authenticated_client.session_transaction() as flask_session:
        flask_session.clear()
    signup_page = authenticated_client.get("/signup")
    token = re.search(rb'name="csrf_token" value="([^"]+)"', signup_page.data).group(1).decode()
    mismatch = authenticated_client.post(
        "/signup",
        data={
            "csrf_token": token,
            "username": "safe-user",
            "password": "Strong-password-123",
            "password_confirm": "Different-password-123",
        },
    )
    assert mismatch.status_code == 400
    assert b"Passwords do not match" in mismatch.data

    weak = authenticated_client.post(
        "/signup",
        data={
            "csrf_token": token,
            "username": "weak-user",
            "password": "alllowercase123",
            "password_confirm": "alllowercase123",
        },
    )
    assert weak.status_code == 400
    assert b"at least 3" in weak.data


def test_admin_can_manage_roles_but_cannot_remove_last_admin(authenticated_client):
    with authenticated_client.session_transaction() as flask_session:
        flask_session.clear()
    signup_page = authenticated_client.get("/signup")
    token = re.search(rb'name="csrf_token" value="([^"]+)"', signup_page.data).group(1).decode()
    authenticated_client.post(
        "/signup",
        data={
            "csrf_token": token,
            "username": "managed-user",
            "password": "Managed-user-123",
            "password_confirm": "Managed-user-123",
        },
    )
    login_page = authenticated_client.get("/login")
    login_token = re.search(rb'name="csrf_token" value="([^"]+)"', login_page.data).group(1).decode()
    authenticated_client.post(
        "/login",
        data={
            "csrf_token": login_token,
            "username": "researcher",
            "password": "test-password-123",
        },
    )
    users = authenticated_client.get("/api/admin/users")
    assert users.status_code == 200
    assert {user["username"] for user in users.json["users"]} == {
        "researcher",
        "managed-user",
    }
    last_admin = authenticated_client.post(
        "/api/admin/users/researcher/role",
        data={"role": "user"},
        headers=_csrf_header(authenticated_client),
    )
    assert last_admin.status_code == 409
    promote = authenticated_client.post(
        "/api/admin/users/managed-user/role",
        data={"role": "admin"},
        headers=_csrf_header(authenticated_client),
    )
    assert promote.status_code == 409
    assert "Only one administrator" in promote.json["error"]
    demote = authenticated_client.post(
        "/api/admin/users/managed-user/role",
        data={"role": "user"},
        headers=_csrf_header(authenticated_client),
    )
    assert demote.status_code == 200


def test_inference_rejects_unsupported_extension(authenticated_client):
    response = authenticated_client.post(
        "/api/predict",
        data={"image": (BytesIO(b"not an image"), "sample.gif"), "run_name": "research-run"},
        headers=_csrf_header(authenticated_client),
        content_type="multipart/form-data",
    )

    assert response.status_code == 415
    assert response.json["error"] == "Upload a PNG or JPEG image."


def test_inference_rejects_invalid_image(authenticated_client):
    response = authenticated_client.post(
        "/api/predict",
        data={"image": (BytesIO(b"not an image"), "sample.png"), "run_name": "research-run"},
        headers=_csrf_header(authenticated_client),
        content_type="multipart/form-data",
    )

    assert response.status_code == 400
    assert response.json["error"] == "The uploaded file is not a readable image."


def test_inference_rejects_tiny_image(authenticated_client):
    response = authenticated_client.post(
        "/api/predict",
        data={"image": (_png_bytes((16, 16)), "sample.png"), "run_name": "research-run"},
        headers=_csrf_header(authenticated_client),
        content_type="multipart/form-data",
    )

    assert response.status_code == 400
    assert "at least 32" in response.json["error"]


def test_inference_rejects_upload_over_size_limit(authenticated_client):
    response = authenticated_client.post(
        "/api/predict",
        data={
            "image": (BytesIO(b"x" * (10 * 1024 * 1024 + 1)), "sample.png"),
            "run_name": "research-run",
        },
        headers=_csrf_header(authenticated_client),
        content_type="multipart/form-data",
    )

    assert response.status_code == 413
    assert "10 MB" in response.json["error"]


def test_inference_reports_missing_model(authenticated_client):
    response = authenticated_client.post(
        "/api/predict",
        data={"image": (_png_bytes(), "sample.png"), "run_name": "missing"},
        headers=_csrf_header(authenticated_client),
        content_type="multipart/form-data",
    )

    assert response.status_code == 404
    assert "not trained and calibrated" in response.json["error"]


def test_inference_uses_selected_model_and_returns_prediction(
    authenticated_client, monkeypatch
):
    _make_model_files(authenticated_client)

    def fake_predictor(_run_directory):
        return object(), {"config": {"size": 64}}, {}

    def fake_predict_tensor(_model, image_tensor, _calibration):
        assert tuple(image_tensor.shape) == (1, 3, 64, 64)
        return {
            "status": "RESEARCH_PREDICTION",
            "label": "no_tumor",
            "tumor_model_probability": 0.12,
            "review_score": 0.08,
            "warning": "Research output only.",
        }

    monkeypatch.setattr(app_module, "_load_predictor", fake_predictor)
    monkeypatch.setattr(app_module, "predict_tensor", fake_predict_tensor)
    response = authenticated_client.post(
        "/api/predict",
        data={"image": (_png_bytes(), "sample.png"), "run_name": "research-run"},
        headers=_csrf_header(authenticated_client),
        content_type="multipart/form-data",
    )

    assert response.status_code == 200
    assert response.json["label"] == "no_tumor"
    assert response.json["tumor_model_probability"] == 0.12


def test_model_list_includes_only_complete_calibrated_runs(authenticated_client):
    _make_model_files(authenticated_client)

    response = authenticated_client.get("/api/models")

    assert response.status_code == 200
    assert response.json["enabled"] is True
    assert response.json["models"] == ["research-run"]


def test_radiologist_review_requires_structured_decision(authenticated_client):
    with authenticated_client.application.app_context():
        import sqlite3

        connection = sqlite3.connect(
            authenticated_client.application.config["AUTH_DB"]
        )
        connection.execute(
            "INSERT INTO review_queue(review_id, study_id, inference_id, model) "
            "VALUES(?,?,?,?)",
            ("review-123", "study-123", "inference-123", "research-run"),
        )
        connection.commit()
        connection.close()

    response = authenticated_client.post(
        "/api/radiologist-review",
        json={"inference_id": "inference-123", "decision": "agree", "reason": "Reviewed"},
        headers=_csrf_header(authenticated_client),
    )

    assert response.status_code == 200
    assert response.json["recorded"] is True
    assert response.json["mandatory_radiologist_review"] is True
    assert response.json["reviewed_by"] == "researcher"

    duplicate = authenticated_client.post(
        "/api/radiologist-review",
        json={"inference_id": "inference-123", "decision": "agree"},
        headers=_csrf_header(authenticated_client),
    )
    assert duplicate.status_code == 409


def test_training_rejects_invalid_run_name(authenticated_client):
    response = authenticated_client.post(
        "/api/train",
        data={"manifest_path": "manifest.csv", "run_name": "../escape", "epochs": "2"},
        headers=_csrf_header(authenticated_client),
    )

    assert response.status_code == 400
    assert "Run name" in response.json["error"]


def test_setup_rejects_weak_password(tmp_path):
    application = app_module.create_app(
        {
            "TESTING": True,
            "INSTANCE_PATH": str(tmp_path / "instance"),
            "RUNS_DIR": str(tmp_path / "runs"),
        }
    )
    client = application.test_client()
    setup_page = client.get("/setup")
    token = re.search(rb'name="csrf_token" value="([^"]+)"', setup_page.data).group(1).decode()

    response = client.post(
        "/setup",
        data={"csrf_token": token, "username": "researcher", "password": "weak"},
    )

    assert response.status_code == 400
    assert b"at least 12 characters" in response.data
