import json

from compare_architectures import inspect_architecture


def test_supported_architectures_produce_binary_logits():
    for architecture in ("cnn", "resnet50", "efficientnet_b0"):
        result = inspect_architecture(architecture, image_size=32)
        assert result["forward_pass_ok"] is True
        assert result["output_shape"] == [1, 2]
        assert result["parameter_count"] > 0


def test_comparison_report_is_json_serializable():
    result = inspect_architecture("cnn", image_size=32)
    assert json.dumps(result)
