import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
import pytest
import torch
from core import MRIModel, SUPPORTED_ARCHITECTURES, read_manifest
from selective import probability_and_score
from metrics import metrics
from train import symmetric_kl

def test_model_shape():
    for architecture in SUPPORTED_ARCHITECTURES:
        model = MRIModel(architecture).eval()
        with torch.no_grad():
            assert model(torch.rand(2, 3, 64, 64)).shape == (2, 2)

def test_stability_and_probabilities():
    logits = torch.tensor([[[8.,-8.]] * 4, [[8.,-8.],[-8.,8.],[8.,-8.],[-8.,8.]]])
    p, s = probability_and_score(logits,1.)
    assert torch.allclose(p.sum(1),torch.ones(2))
    assert s[0] < s[1]
    assert bool(((s >= 0) & (s <= 1)).all())

def test_symmetric_kl_identical():
    x = torch.tensor([[1.,2.],[3.,1.]])
    assert abs(float(symmetric_kl(x,x))) < 1e-6

def test_metrics():
    m = metrics(np.array([0,0,1,1]),np.array([.1,.2,.8,.9]))
    assert m['roc_auc'] == 1.
    assert m['specificity'] == 1.
    assert m['confusion_matrix_tn_fp_fn_tp'] == [2,0,0,2]
    assert metrics([],[])['n'] == 0

def test_patient_leakage_rejected(tmp_path):
    path = tmp_path / 'manifest.csv'
    pd.DataFrame({'path':['a.png','b.png'], 'label':[0,0],
                  'patient_id':['p1','p1'], 'split':['train','test']}).to_csv(path,index=False)
    with pytest.raises(ValueError):
        read_manifest(path)

def test_missing_patient_id_rejected(tmp_path):
    path = tmp_path / 'manifest.csv'
    pd.DataFrame({'path':['a.png'], 'label':[0], 'patient_id':[' ']}).to_csv(path,index=False)
    with pytest.raises(ValueError):
        read_manifest(path,require_split=False)
