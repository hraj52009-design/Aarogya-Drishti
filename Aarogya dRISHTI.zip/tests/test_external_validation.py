import numpy as np
import pandas as pd
import pytest
from PIL import Image

from external_validation import (
    audit_external_against_training,
    build_external_report,
    external_cohort_preflight,
    load_external_manifest,
)
from metrics import calibration_curve, prevalence_metrics, threshold_metrics


def _image(path, color):
    Image.new("RGB", (40, 40), color=color).save(path, format="PNG")
    return str(path)


def _external_manifest(tmp_path, rows):
    manifest = tmp_path / "external.csv"
    pd.DataFrame(rows).to_csv(manifest, index=False)
    return manifest


def test_external_manifest_requires_patient_and_site_metadata(tmp_path):
    image_path = _image(tmp_path / "sample.png", (1, 2, 3))
    manifest = _external_manifest(
        tmp_path, {"path": [image_path], "label": [0], "group_id": ["subject-1"]}
    )

    with pytest.raises(ValueError, match="requires columns"):
        load_external_manifest(manifest)


def test_external_manifest_requires_both_reference_classes(tmp_path):
    image_path = _image(tmp_path / "sample.png", (1, 2, 3))
    manifest = _external_manifest(
        tmp_path,
        {
            "path": [image_path],
            "label": [0],
            "patient_id": ["subject-1"],
            "site_id": ["site-1"],
        },
    )

    with pytest.raises(ValueError, match="both reference-label classes"):
        load_external_manifest(manifest)


def test_external_manifest_rejects_pixel_identical_duplicates(tmp_path):
    first = _image(tmp_path / "first.png", (1, 2, 3))
    second = _image(tmp_path / "second.png", (1, 2, 3))
    manifest = _external_manifest(
        tmp_path,
        {
            "path": [first, second],
            "label": [0, 1],
            "patient_id": ["subject-1", "subject-2"],
            "site_id": ["site-1", "site-1"],
        },
    )

    with pytest.raises(ValueError, match="pixel-identical duplicate"):
        load_external_manifest(manifest)


def test_image_group_training_data_is_not_eligible_for_external_gate(tmp_path):
    external = pd.DataFrame(
        {"patient_id": ["external-1"], "path": ["unused.png"], "group_id": ["external-1"]}
    )
    training = pd.DataFrame(
        {"group_id": ["image-1"], "path": ["unused-training.png"]}
    )

    with pytest.raises(ValueError, match="true pseudonymous patient_id"):
        audit_external_against_training(external, training)


def test_external_report_keeps_frozen_metrics_and_site_strata():
    calibration = {"threshold": 0.7}
    labels = np.array([0, 0, 1, 1])
    probabilities = np.array([0.1, 0.8, 0.7, 0.9])
    review_scores = np.array([0.1, 0.8, 0.2, 0.9])
    patients = np.array(["p1", "p2", "p3", "p4"])
    sites = np.array(["site-a", "site-a", "site-b", "site-b"])

    report = build_external_report(
        labels, probabilities, review_scores, patients, sites, calibration, bootstrap=10
    )

    assert report["evaluation_type"] == "external patient-grouped image-level validation"
    assert report["n_patients"] == 4
    assert report["n_sites"] == 2
    assert report["full_cohort"]["confusion_matrix_tn_fp_fn_tp"] == [1, 1, 0, 2]
    assert report["review_count"] == 2
    assert report["coverage_by_true_class"] == {"0": 0.5, "1": 0.5}
    assert set(report["site_strata"]) == {"site-a", "site-b"}
    assert "must not guide care" in report["warning"]
    assert report["operating_points"]["0.35"]["sensitivity"] == 1.0
    assert "0.1" in report["prevalence_aware_ppv_npv_at_decision_threshold"]
    assert report["calibration"]["reliability_bins"]
    assert report["cohort_preflight"]["patient_count"] == 4


def test_external_preflight_flags_single_site_cohort():
    cohort = pd.DataFrame(
        {
            "patient_id": ["p1", "p2"],
            "site_id": ["site-a", "site-a"],
            "label": [0, 1],
        }
    )

    preflight = external_cohort_preflight(cohort)

    assert preflight["has_multiple_sites"] is False
    assert preflight["evaluation_gate"] == "single_site_external_cohort_requires_caution"


def test_validation_helpers_expose_operating_and_calibration_details():
    labels = np.array([0, 0, 1, 1])
    probabilities = np.array([0.1, 0.8, 0.7, 0.9])
    assert threshold_metrics(labels, probabilities, 0.35)["false_negative_count"] == 0
    assert prevalence_metrics(labels, probabilities, 0.5)["0.1"]["npv"] > 0
    assert len(calibration_curve(labels, probabilities)) > 0
