from io import BytesIO

import numpy as np
import nibabel as nib
import pydicom
import pytest
from pydicom.dataset import FileDataset, FileMetaDataset

from medical_formats import validate_medical_file


def _dicom_bytes(patient_name=None):
    meta = FileMetaDataset()
    meta.MediaStorageSOPClassUID = pydicom.uid.MRImageStorage
    meta.MediaStorageSOPInstanceUID = pydicom.uid.generate_uid()
    meta.TransferSyntaxUID = pydicom.uid.ExplicitVRLittleEndian
    dataset = FileDataset("test.dcm", {}, file_meta=meta, preamble=b"\0" * 128)
    dataset.Rows = 64
    dataset.Columns = 64
    dataset.Modality = "MR"
    dataset.SeriesInstanceUID = pydicom.uid.generate_uid()
    if patient_name is not None:
        dataset.PatientName = patient_name
    output = BytesIO()
    dataset.save_as(output, write_like_original=False)
    return output.getvalue()


def _nifti_bytes():
    image = nib.Nifti1Image(np.zeros((16, 16, 8), dtype=np.float32), np.eye(4))
    output = BytesIO()
    file_map = image.make_file_map()
    file_map["image"].fileobj = output
    image.to_file_map(file_map)
    return output.getvalue()


def test_dicom_validation_rejects_identifying_metadata():
    with pytest.raises(ValueError, match="identifying metadata"):
        validate_medical_file(_dicom_bytes("REDACTED"), "scan.dcm")


def test_dicom_validation_returns_safe_metadata():
    result = validate_medical_file(_dicom_bytes(), "scan.dcm")
    assert result["format"] == "DICOM"
    assert result["phi_detected"] is False
    assert result["rows"] == 64


def test_nifti_validation_returns_volume_shape():
    result = validate_medical_file(_nifti_bytes(), "study.nii")
    assert result["format"] == "NIfTI"
    assert result["shape"] == (16, 16, 8)
    assert result["phi_detected"] is False
