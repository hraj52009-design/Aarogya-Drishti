import pandas as pd
import pytest
from PIL import Image

from patient_pipeline import (
    build_pipeline_report,
    create_patient_splits,
    validate_patient_manifest,
)


def _make_manifest(tmp_path, patients=8):
    rows = []
    for index in range(patients):
        label = index % 2
        patient_id = f"patient-{index}"
        image_path = tmp_path / f"{patient_id}.png"
        Image.new("RGB", (32, 32), color="white" if label else "black").save(image_path)
        rows.append(
            {
                "path": image_path.name,
                "label": label,
                "patient_id": patient_id,
                "study_id": f"study-{index}",
                "site_id": "site-a" if index < patients // 2 else "site-b",
                "sequence": "FLAIR",
            }
        )
    manifest = tmp_path / "manifest.csv"
    pd.DataFrame(rows).to_csv(manifest, index=False)
    return manifest


def test_patient_manifest_split_keeps_each_patient_together(tmp_path):
    manifest = _make_manifest(tmp_path, patients=20)
    frame = validate_patient_manifest(manifest)
    split_frame = create_patient_splits(frame)

    assert split_frame.groupby("patient_id")["split"].nunique().max() == 1
    report = build_pipeline_report(split_frame)
    assert report["patient_count"] == 20
    assert set(report["patients_by_split"]) == {"train", "val", "cal", "test"}


def test_patient_manifest_rejects_patient_split_leakage(tmp_path):
    manifest = _make_manifest(tmp_path, patients=8)
    frame = pd.read_csv(manifest)
    frame["split"] = "train"
    frame.loc[1, "patient_id"] = frame.loc[0, "patient_id"]
    frame.loc[1, "label"] = frame.loc[0, "label"]
    frame.loc[1, "split"] = "test"
    frame.loc[0, "split"] = "train"
    frame.to_csv(manifest, index=False)

    with pytest.raises(ValueError, match="more than one split"):
        validate_patient_manifest(manifest)


def test_patient_manifest_requires_site_and_patient_ids(tmp_path):
    manifest = tmp_path / "manifest.csv"
    pd.DataFrame({"path": ["image.png"], "label": [1]}).to_csv(manifest, index=False)

    with pytest.raises(ValueError, match="requires columns"):
        validate_patient_manifest(manifest, require_existing_files=False)
