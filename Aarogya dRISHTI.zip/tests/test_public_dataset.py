import csv
from io import BytesIO
import json

import pyarrow as arrow
import pyarrow.parquet as parquet
import pytest
from PIL import Image

from core import read_manifest
from download_brain_tumor_dataset import create_manifest


def _encoded_image(index, label):
    buffer = BytesIO()
    Image.new(
        "RGB",
        (40, 40),
        color=((index * 11 + label * 43) % 256, (index * 17 + 3) % 256, (index + label) % 256),
    ).save(buffer, format="JPEG")
    return {"bytes": buffer.getvalue(), "path": f"sample_{index}.jpg"}


def _write_parquet(path, count_per_class, offset=0):
    images = []
    labels = []
    index = offset
    for label in range(4):
        for _ in range(count_per_class):
            images.append(_encoded_image(index, label))
            labels.append(label)
            index += 1
    table = arrow.table(
        {
            "image": arrow.array(images, type=arrow.struct([("bytes", arrow.binary()), ("path", arrow.string())])),
            "label": arrow.array(labels, type=arrow.int64()),
        }
    )
    parquet.write_table(table, path)
    return len(labels)


def test_public_dataset_manifest_preserves_test_split(tmp_path):
    train_path = tmp_path / "train.parquet"
    test_path = tmp_path / "test.parquet"
    train_count = _write_parquet(train_path, count_per_class=10)
    test_count = _write_parquet(test_path, count_per_class=4, offset=1000)
    manifest_path = tmp_path / "manifest.csv"

    rows = create_manifest(
        train_path,
        test_path,
        manifest_path,
        seed=42,
        expected_train_count=train_count,
        expected_test_count=test_count,
    )

    with manifest_path.open(newline="", encoding="utf-8") as source:
        manifest_rows = list(csv.DictReader(source))
    assert len(rows) == train_count + test_count
    assert len([row for row in manifest_rows if row["split"] == "test"]) == test_count
    assert all(row["source_partition"] == "test" for row in manifest_rows if row["split"] == "test")
    assert all(row["source_partition"] == "train" for row in manifest_rows if row["split"] != "test")
    assert {row["source_class"] for row in manifest_rows} == {
        "glioma",
        "meningioma",
        "no_tumor",
        "pituitary",
    }
    assert {row["label"] for row in manifest_rows if row["source_class"] == "no_tumor"} == {"0"}
    assert {row["label"] for row in manifest_rows if row["source_class"] != "no_tumor"} == {"1"}
    assert set(read_manifest(manifest_path)["split"]) == {"train", "val", "cal", "test"}


def test_public_dataset_manifest_removes_training_duplicates_of_test(tmp_path):
    train_path = tmp_path / "train.parquet"
    test_path = tmp_path / "test.parquet"
    train_count = _write_parquet(train_path, count_per_class=10)
    _write_parquet(test_path, count_per_class=4, offset=1000)
    test_table = parquet.read_table(test_path).to_pylist()
    train_table = parquet.read_table(train_path).to_pylist()
    test_table[0]["image"] = train_table[0]["image"]
    parquet.write_table(arrow.Table.from_pylist(test_table), test_path)
    manifest_path = tmp_path / "manifest.csv"

    create_manifest(
        train_path,
        test_path,
        manifest_path,
        seed=2,
        expected_train_count=train_count,
        expected_test_count=16,
    )
    attribution = json.loads(
        (tmp_path / "dataset-attribution.json").read_text(encoding="utf-8")
    )

    assert attribution["duplicate_rows_removed"]["training_rows_overlapping_test_removed"] == 1


def test_public_dataset_manifest_does_not_overwrite_existing_file(tmp_path):
    train_path = tmp_path / "train.parquet"
    test_path = tmp_path / "test.parquet"
    train_count = _write_parquet(train_path, count_per_class=10)
    test_count = _write_parquet(test_path, count_per_class=4, offset=1000)
    manifest_path = tmp_path / "manifest.csv"
    manifest_path.write_text("existing", encoding="utf-8")

    with pytest.raises(FileExistsError):
        create_manifest(
            train_path,
            test_path,
            manifest_path,
            expected_train_count=train_count,
            expected_test_count=test_count,
        )
