import torch

from selective import uncertainty_components, uncertainty_summary


def test_uncertainty_components_distinguish_stable_and_disagreeing_views():
    stable = torch.tensor([[[4.0, 0.0]] * 4])
    unstable = torch.tensor([[[4.0, 0.0], [0.0, 4.0], [4.0, 0.0], [0.0, 4.0]]])
    stable_entropy, stable_disagreement = uncertainty_components(stable.softmax(-1))
    unstable_entropy, unstable_disagreement = uncertainty_components(
        unstable.softmax(-1)
    )

    assert unstable_disagreement[0] > stable_disagreement[0]
    assert stable_entropy[0] < unstable_entropy[0]


def test_uncertainty_summary_reports_abstention_counts():
    logits = torch.tensor(
        [[[4.0, 0.0], [4.0, 0.0], [4.0, 0.0], [4.0, 0.0]],
         [[4.0, 0.0], [0.0, 4.0], [4.0, 0.0], [0.0, 4.0]]]
    )
    summary = uncertainty_summary(logits, temperature=1.0, threshold=0.2)

    assert summary["retained_count"] == 1
    assert summary["review_count"] == 1
    assert 0 <= summary["retained_fraction"] <= 1
