import json

import pandas as pd
from PIL import Image

from audit_dataset import audit_manifest
from freeze_baseline import freeze_run


def _write_image(path, color):
    Image.new("RGB", (32, 32), color=color).save(path)


def test_dataset_audit_reports_duplicate_and_patient_metadata(tmp_path):
    first = tmp_path / "first.png"
    second = tmp_path / "second.png"
    _write_image(first, "black")
    _write_image(second, "black")
    manifest = tmp_path / "manifest.csv"
    pd.DataFrame(
        {
            "path": [first.name, second.name],
            "label": [0, 1],
            "patient_id": ["patient-a", "patient-b"],
            "group_id": ["patient-a", "patient-b"],
            "split": ["train", "test"],
        }
    ).to_csv(manifest, index=False)

    report = audit_manifest(manifest)

    assert report["patient_id_present"] is True
    assert report["pixel_duplicate_groups"]
    assert report["split_group_overlap"] == {}


def test_freeze_run_captures_hashes_and_limitations(tmp_path):
    run = tmp_path / "run"
    run.mkdir()
    (run / "best.pt").write_bytes(b"checkpoint")
    (run / "config.json").write_text(
        json.dumps({"manifest": str(tmp_path / "manifest.csv")}), encoding="utf-8"
    )
    for name in ("provenance.json", "calibration.json", "test_report.json"):
        (run / name).write_text("{}", encoding="utf-8")

    output = tmp_path / "freeze.json"
    snapshot = freeze_run(run, output)

    assert output.is_file()
    assert snapshot["artifact_sha256"]["best.pt"]
    assert "patient-independent" in " ".join(snapshot["known_limitations"])
