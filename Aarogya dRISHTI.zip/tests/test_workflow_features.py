import re

import app as app_module


def _client(tmp_path):
    application = app_module.create_app(
        {
            "TESTING": True,
            "INSTANCE_PATH": str(tmp_path / "instance"),
            "RUNS_DIR": str(tmp_path / "runs"),
            "RESEARCH_INFERENCE_ENABLED": True,
        }
    )
    client = application.test_client()
    page = client.get("/setup")
    token = re.search(rb'name="csrf_token" value="([^"]+)"', page.data).group(1).decode()
    client.post(
        "/setup",
        data={"csrf_token": token, "username": "researcher", "password": "test-password-123"},
    )
    return client


def _csrf(client):
    with client.session_transaction() as session:
        return {"X-CSRFToken": session["csrf_token"]}


def test_workflow_pages_and_monitoring_are_available(tmp_path):
    client = _client(tmp_path)
    assert client.get("/study").status_code == 200
    assert client.get("/review-queue").status_code == 404
    assert client.get("/monitoring").status_code == 200
    assert client.get("/api/review-queue").json == {"items": []}
    assert client.get("/api/monitoring").json["total_inferences"] == 0


def test_patient_summary_endpoint_remains_available(tmp_path):
    client = _client(tmp_path)
    response = client.post(
        "/api/patient-summary",
        json={
            "patient_id": "study-1",
            "predictions": [
                {"status": "RESEARCH_PREDICTION", "tumor_model_probability": 0.4}
            ],
        },
        headers=_csrf(client),
    )
    assert response.status_code == 200
    assert response.json["ai_finding"] == "SUSPICIOUS"
